 create database second_hand_commodities_trading;
 use second_hand_commodities_trading;
 --用户表--
 create table SHCT_User(
   User_ID char(8) not null primary key,
   Nick_Name varchar(20) not null,
   User_Name varchar(20) not null,
   Gender varchar(6) not null,
   ID_Card char(18) not null,
   Tel char(11) not null,
   E_Mail varchar(30) not null,
   Address varchar(50) not null,
   Buyer_Credit int,
   Saler_Credit int 
 );
alter table SHCT_User
CHANGE COLUMN `Gender` `Gender` SET('Male', 'Female') NOT NULL ;
--用户登录表--
create table SHCT_Login(
  User_ID char(8) not null primary key,
  PassWord varchar(20) not null
);
--商品表--
create table SHCT_Commodities(
  Commodity_ID char(8) not null primary key,
  User_ID char(8) not null,
  Type_ID char(3) not null,
  Commodity_Name varchar(20) not null,
  Pictures_Linking varchar(100) not null,
  Commodity_Dp varchar(200) not null,
  Purity varchar(10) not null,
  Transaction_Type varchar(5) not null,
  Price decimal ,
  Exchange_Need varchar(200) ,
  foreign key(User_ID) references SHCT_User(User_ID) on update cascade on delete restrict,
  foreign key(Type_ID) references SHCT_Type(Type_ID) on update cascade on delete restrict
);
alter table SHCT_Commodities
CHANGE COLUMN `Transaction_Type` `Transaction_Type` SET('Money', 'Good','Both') NOT NULL ;

--类型表--
create table SHCT_Type(
  Type_ID char(3) not null primary key,
  Type_Name varchar(20) not null
);
--订单表--
create table SHCT_Order(
  Order_ID char(10) not null primary key,
  Saler_ID char(8) not null,
  Buyer_ID char(8) not null,
  Order_Status varchar(10) not null,
  Order_date datetime not null,
  foreign key(Saler_ID) references SHCT_User(User_ID) on update cascade on delete restrict,
  foreign key(Buyer_ID) references SHCT_User(User_ID) on update cascade on delete restrict
);
alter table SHCT_Order
CHANGE COLUMN `Order_Status` `TOrder_Status` SET('Check', 'Amount Due','Finish','Cancel') NOT NULL ;

--交易表--
create table SHCT_Transaction(
  Transaction_ID char(10) not null primary key,
  Order_ID char(10)
  Delivery_ID varchar(20) not null,
  Transaction_date datetime not null,
  Transaction_Grade int not null,
  foreign key(Order_ID) references SHCT_Order(Order_ID) on update cascade on delete restrict
);
alter table SHCT_Order
CHANGE COLUMN `Transaction_Grade` `Transaction_Grade` SET('1', '2','3','4','5') NOT NULL ;
--提问表--
create table SHCT_Question(
  Question_ID int not null primary key auto_increment,
  Commodity_ID char(8) not null,
  User_ID char(8) not null,
  Question varchar(500) not null,
  Fa_ID char(8),
  Comment_date datetime not null,
  foreign key(Commodity_ID) references SHCT_Commodities(Commodity_ID) on update cascade on delete restrict,
  foreign key(User_ID) references SHCT_User(User_ID) on update cascade on delete restrict,
  foreign key(Fa_ID) references SHCT_User(User_ID) on update cascade on delete restrict
);
--快递表--
create table SHCT_Delivery(

);
--管理员表--
create table SHCT_Admin(
  Admin_ID char(4) not null primary key,
);