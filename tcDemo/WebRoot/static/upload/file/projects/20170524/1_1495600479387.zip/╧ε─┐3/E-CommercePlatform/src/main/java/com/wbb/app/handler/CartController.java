package com.wbb.app.handler;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.google.gson.Gson;
import com.wbb.app.dao.UserMapper;
import com.wbb.app.model.BuyDetails;
import com.wbb.app.model.Product;
import com.wbb.app.model.ReceiptAddress;
import com.wbb.app.model.ShoppingCart;
import com.wbb.app.model.User;
import com.wbb.app.service.ProductService;

@Controller
public class CartController {

	@Resource
	HttpServletRequest request;
	@Resource
	ProductService productService;
	@Resource
	HttpServletResponse response;
	@Resource
	UserMapper userMapper;

	@RequestMapping("/addToCart")
	public String addToCart() {
		String b = "";
		String id = request.getParameter("p_id");
		System.out.println("ID:" + id);
		boolean flag = false;
		ShoppingCart sc = productService.getShoppingCart(request);
		flag = productService.addToCart(id, sc);
		if (flag) {
			b = "cart";
		}
		return b;
	}

	@ResponseBody
	@RequestMapping(value = "updateItemQuantity", produces = "application/json;charset=UTF-8")
	public String updateItemQuantity() throws IOException {
		String idStr = request.getParameter("id");
		String quantityStr = request.getParameter("quantity");
		ShoppingCart sc = productService.getShoppingCart(request);
		int quantity = -1;
		try {
			quantity = Integer.parseInt(quantityStr);
		} catch (Exception e) {
		}

		if (quantity > 0) {
			productService.updateItemQuantity(sc, idStr, quantity);
		}
		Map<String, Object> result = new HashMap<String, Object>();
		result.put("productNumber", sc.getProductNumber());
		result.put("totalMoney", sc.getTotalMoney());
		System.out.println(sc.getProductNumber());
		System.out.println(sc.getTotalMoney());

		Gson gson = new Gson();
		String jsonStr = gson.toJson(result);

		return jsonStr;
	}

	@RequestMapping("remove")
	public String remove() {
		String idStr = request.getParameter("id");
		ShoppingCart sc = productService.getShoppingCart(request);
		productService.removeItemFromShoppingCart(sc, idStr);

		return "cart";
	}

	@RequestMapping("/clear")
	public String clear() {
		ShoppingCart sc = productService.getShoppingCart(request);
		productService.clearShoppingCart(sc);
		return "cart";
	}

	@RequestMapping("/checkout")
	public String checkout(Map<String, Object> map) {
		String id = (String) request.getSession().getAttribute("id");
		List<ReceiptAddress> receiptAddresses = userMapper.getReceiptAddress(id);
		System.out.println(receiptAddresses);
		map.put("receiptAddresses", receiptAddresses);
		return "checkout";
	}

	@ResponseBody
	@RequestMapping(value = "/newAddress", produces = "application/json;charset=UTF-8")
	public String newAddress() throws Exception {
		request.setCharacterEncoding("UTF-8");
		String id = (String) request.getSession().getAttribute("id");
		String name = request.getParameter("name");
		String address = request.getParameter("address");
		String phone = request.getParameter("phone");
		ReceiptAddress receiptAddress = new ReceiptAddress(name, phone, address, id);
		userMapper.addReceiptAddress(receiptAddress);
		Gson gson = new Gson();
		String jsonStr = gson.toJson("true");

		return "true";

	}

	@RequestMapping("/submitOrder")
	public String submitOrder() throws Exception{
		request.setCharacterEncoding("UTF-8");
		String address=request.getParameter("radio");
		
		String a[] = address.split("and");  
		String p_id="";
		int length=Integer.parseInt(request.getParameter("length"));
		int price=0,quantity=0,cost=0;
		String name="";
		System.out.println(p_id);
		BuyDetails buyDetails=null;
		String bd_request="";
		String bd_state="false";
		String bd_confirm="false";
		Date today = new Date();
		 String date = String.valueOf((today.getYear() + 1900) + "-" + (today.getMonth() + 1) + "-" + today.getDate());
		 String bd_name=a[1];
		 String bd_phone=a[2];
		 String bd_address=a[0];
		 request.getSession().setAttribute("address", bd_address);
		 String u_id=(String) request.getSession().getAttribute("id");		
		for(int i=1;i<=length;i++){
			p_id=request.getParameter("p"+i);
			price=Integer.parseInt(request.getParameter("price"+i));
			quantity=Integer.parseInt(request.getParameter("quantity"+i));
			cost=price*quantity;
			name=request.getParameter("name"+i);
			bd_request="i want to buy..."+name;
			System.out.println(p_id);
			System.out.println(name);
			System.out.println("P_idCost:"+price*quantity);
			buyDetails=new BuyDetails(bd_request, bd_state,bd_confirm,"false","false",date,quantity,cost,
			bd_name,bd_phone, bd_address,u_id,p_id);
			userMapper.addBuyDetails(buyDetails);	
		}
		return "afterSubmitOrder";
	}
	@ResponseBody
	@RequestMapping(value="/confirmPayment",produces = "application/json;charset=UTF-8")
	public String confirmPayment(Map<String, Object>map){
		String u_id=(String) request.getSession().getAttribute("id");
		String password=request.getParameter("password");
		System.out.println(password);
		System.out.println((String)request.getSession().getAttribute("password"));
		if(password.equalsIgnoreCase((String)request.getSession().getAttribute("password"))){
			double cost=Double.parseDouble(request.getParameter("money"));
			System.out.println(cost);
			User user = userMapper.getUserByID(u_id);
			int money=(int) (user.getMoney()-cost);
			if(money>0){
				System.out.println(money);
			    userMapper.payment(money,u_id);
			    userMapper.payment1("true", u_id);
			    map.put("message","֧���ɹ�");
			}
			else{
				map.put("message", "���㣬֧��ʧ�ܣ�����");
			}
		}
		else{
			map.put("message", "���������������ȷ�����룡����");
		}
		Gson gson = new Gson();
		String jsonStr = gson.toJson(map);
		return jsonStr;
	}

}
