/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.wbb.app.model;
/**
 *
 * @author AlbertPC
 */
public class Shop {
    private String id;
    private String name;
    private Product product;
    
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Product getProduct() {
        return product;
    }

    public void setProduct(Product product) {
        this.product = product;
    }
    

    public Shop(String id,String name) {
        this.id=id;
        this.name = name;
    }

    public Shop(String id, String name, Product product) {
        this.id = id;
        this.name = name;
        this.product = product;
    }
    
    public Shop() {
    }

	@Override
	public String toString() {
		return "Shop [id=" + id + ", name=" + name + "]";
	}
    	
}
