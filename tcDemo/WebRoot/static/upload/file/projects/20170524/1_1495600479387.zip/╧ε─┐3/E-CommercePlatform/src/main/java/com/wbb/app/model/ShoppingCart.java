package com.wbb.app.model;



import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

public class ShoppingCart {

    private Map<String, ShoppingCartItem> products = new HashMap<>();

    public void updateItemQuantity(String id, int quantity) {
        ShoppingCartItem sci = products.get(id);
        if (sci != null) {
            sci.setQuantity(quantity);
        }
    }

    public void removeItem(String id) {
        products.remove(id);
    }

  
    public void clear() {
        products.clear();
    }

    public boolean isEmpty() {
        return products.isEmpty();
    }

    public float getTotalMoney() {
        float total = 0;

        for (ShoppingCartItem sci : getItems()) {
            total += sci.getItemMoney();
        }

        return total;
    }

    public Collection<ShoppingCartItem> getItems() {
        return products.values();
    }

    public int getProductNumber() {
        int total = 0;

        for (ShoppingCartItem sci : products.values()) {
            total += sci.getQuantity();
        }

        return total;
    }

    public Map<String, ShoppingCartItem> getProducts() {
        return products;
    }

    public boolean hasProduct(String id) {
        return products.containsKey(id);
    }

    /**
	 * ���ﳵ������һ����Ʒ		
	 * @param product
	 */
    public void addProduct(Product product) {

        ShoppingCartItem sci = products.get(product.getId());

        if (sci == null) {
            sci = new ShoppingCartItem(product);
            products.put(product.getId(), sci);
        } else {
            sci.increment();
        }
    }
}
