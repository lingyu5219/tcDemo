package com.wbb.app.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.wbb.app.model.BuyDetails;
import com.wbb.app.model.ReceiptAddress;
import com.wbb.app.model.Secretsecurity;
import com.wbb.app.model.User;


public interface UserMapper {

	public User getUserByID(String id);
	public List<User> getUser();
	public void register(User user);
	public void addReceiptAddress(ReceiptAddress receiptAddress);
	public List<ReceiptAddress> getReceiptAddress(String id);
	public void addBuyDetails(BuyDetails buyDetails);
	public void payment(@Param("money")int money,@Param("id")String id);
	public void payment1(@Param("state")String state,@Param("id")String id);
	public void confirm(@Param("id")String id,@Param("confirm")String confirm);
	public void comment(@Param("comment")String comment,@Param("star")String star,@Param("bd_id")String id);
	public void comment1(@Param("comment")String comment,@Param("bd_id")String id);
	public void deleteAddress(@Param("ra_id")String ra_id);
	public void modifyUser(User user);
	public void changePassword(@Param("u_id")String u_id,@Param("password")String password);
	public String getSecretSecurity(@Param("u_id")String u_id);
	public Secretsecurity getSecretSecurity1(@Param("u_id")String u_id);
	public void setSecretSecurity(Secretsecurity secretsecurity);
	public void setSecretSecurity1(Secretsecurity secretsecurity);
	
}
