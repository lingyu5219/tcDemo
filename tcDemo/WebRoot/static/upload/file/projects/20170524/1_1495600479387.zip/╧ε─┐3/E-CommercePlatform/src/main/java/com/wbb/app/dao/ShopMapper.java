package com.wbb.app.dao;



import org.apache.ibatis.annotations.Param;

import com.wbb.app.model.Product;




public interface ShopMapper {

		
		//���ִ��β��ܻ�ϣ�����@Param
		public void addProduct(@Param("p")Product product,@Param("ca_id")String ca_id,@Param("s_id")String s_id);
		public void updateProduct(Product product);
		public void deleteProduct(@Param("p_id")String p_id);
		public void delivery(@Param("id")String id,@Param("delivery")String delivery);
		public void delivery1(@Param("stock")String stock,@Param("p_id")String p_id);
}
