package com.fashionshopping.model.service;

import com.fashionshopping.model.bean.Category;

public interface CategoryService extends BaseService<Category>{	
	
}
