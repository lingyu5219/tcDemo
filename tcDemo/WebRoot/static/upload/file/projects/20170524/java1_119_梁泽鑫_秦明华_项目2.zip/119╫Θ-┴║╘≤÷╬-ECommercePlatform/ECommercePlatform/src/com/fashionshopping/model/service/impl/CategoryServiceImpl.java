package com.fashionshopping.model.service.impl;


import java.util.ArrayList;

import com.fashionshopping.model.bean.Category;
import com.fashionshopping.model.condb.ConMysql;
import com.fashionshopping.model.service.CategoryService;


public class CategoryServiceImpl extends BaseServiceImpl<Category> implements CategoryService {
	ArrayList<Category> result =new ArrayList<Category>();
    
	public CategoryServiceImpl(){
		super();
	}
	
    //得到商品类别的记录条数（行数）
    public int getRowCount() {
		int rowCount=0;
		try{
			 //得到数据库连接
	        ConMysql connection=new ConMysql();
	        con=connection.getCon();
	        String sql="select count(*) from category";
	        ps=con.prepareStatement(sql); 
	        rs=ps.executeQuery();
	        if(rs.next()){
	        	rowCount=rs.getInt(1);
	        }
       }catch(Exception e){
     	  e.printStackTrace();
       }finally{
     	  this.close();
       }
		return rowCount;
	}   
    //根据id删除类别信息
    public Boolean deleteCategoryByIds(String ids){
       Boolean b=false;
       try{
			 //得到数据库连接
	        ConMysql connection=new ConMysql();
	        con=connection.getCon();
	        String sql="delete from category where id in ("+ids+")";
	        ps=con.prepareStatement(sql); 
	       // ps.setString(1, ids);
	        int i=ps.executeUpdate();
	        if(i!=0){
	        	b=true;
	        }
	        System.out.println("delete ok");
      }catch(Exception e){
    	  e.printStackTrace();
      }finally{
    	  this.close();
      }
       return b;	
    }
    //根据输入类型查询类别信息
    public ArrayList<Category> getSelectedCategory(String categoryType,int pageSize,int pageNow){
    	   try{
  			 //得到数据库连接
  	        ConMysql connection=new ConMysql();
  	        con=connection.getCon();
  	        String sql="select c.id,c.type,c.hot,a.id,a.login from category c left join account as a on a.id=c.aid where type like ? limit ?,?";
  	        ps=con.prepareStatement(sql); 
  	        ps.setString(1,"%"+categoryType+"%");
  	        ps.setInt(2, pageSize*(pageNow-1));
            ps.setInt(3, pageSize);
  	        rs=ps.executeQuery();
  	        while(rs.next()){
  	        	Category c=new Category();
  	        	c.setId(rs.getInt(1));
  	        	c.setType(rs.getString(2));
  	        	c.setHot(rs.getBoolean(3));
  	        	c.setAid(rs.getInt(4));
  	        	c.setLogin(rs.getString(4));
  	        	result.add(c);
  	        }
        }catch(Exception e){
      	  e.printStackTrace();
        }finally{
      	   this.close();
        }
    	 return result;
    }
    //按照查询类型得到行数
    public int getRowCountBySelected(String categoryType) {
		int rowCount=0;
		try{
			 //得到数据库连接
	        ConMysql connection=new ConMysql();
	        con=connection.getCon();
	        String sql="select count(*) from category where type like '%"+categoryType+"%' ";
	        ps=con.prepareStatement(sql); 
	        //ps.setString(1, categoryType);	        
	        rs=ps.executeQuery();
	        if(rs.next()){
	        	rowCount=rs.getInt(1);
	        }
       }catch(Exception e){
     	  e.printStackTrace();
       }finally{
     	  this.close();
       }
		return rowCount;
	}
   //添加类别信息
    public void addCategory(String category,Boolean b){
    	try{
            //得到数据库连接
           ConMysql connection=new ConMysql();
           con=connection.getCon();
           String sql="insert into category (type,hot) values(?,?)";
           ps=con.prepareStatement(sql);
           ps.setString(1, category);
           ps.setBoolean(2, b);
           ps.executeUpdate();
           //System.out.println("insert OK");
        }catch(Exception e){
            e.printStackTrace();
        }finally{
          //关闭资源
          this.close();
        }
    }
    //得到类别集合信息
    public ArrayList<Category> getByPageAndPagesize( int pageNow,int pageSize){
		try{
            //得到数据库连接
           ConMysql connection=new ConMysql();
           con=connection.getCon();
           String sql="select c.id,c.type,c.hot,a.id,a.login from category c left join account a on c.aid=a.id limit ?,?";
           ps=con.prepareStatement(sql);
           ps.setInt(1, pageSize*(pageNow-1));
           ps.setInt(2, pageSize);
           rs=ps.executeQuery();
           while(rs.next()){
        	   Category c=new Category();
        	   c.setId(rs.getInt(1));
        	   c.setType(rs.getString(2));
        	   c.setHot(rs.getBoolean(3));
        	   c.setAid(rs.getInt(4));
        	   c.setLogin(rs.getString(5));
        	   result.add(c);
           }
          }catch(Exception e){
        	  e.printStackTrace();
          }finally{
        	  this.close();
          }		
		return result;
    }
    //得到商品类型（商品下拉列表）
    public ArrayList<Category> getCategoryType(){
    	try{
            //得到数据库连接
           ConMysql connection=new ConMysql();
           con=connection.getCon();
           String sql="select type from category";
           ps=con.prepareStatement(sql);
           rs=ps.executeQuery();
           while(rs.next()){
        	   Category c=new Category();
        	   c.setType(rs.getString(1));
        	   result.add(c);
           }
          }catch(Exception e){
        	  e.printStackTrace();
          }finally{
        	  this.close();
          }		
    	  return result;
    }
}
