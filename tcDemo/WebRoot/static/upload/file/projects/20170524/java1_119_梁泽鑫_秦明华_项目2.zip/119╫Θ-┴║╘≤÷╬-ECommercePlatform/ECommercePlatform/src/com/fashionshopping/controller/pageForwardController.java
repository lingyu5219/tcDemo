package com.fashionshopping.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class pageForwardController extends HttpServlet {

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		this.doPost(request, response);
	}
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		//设置请求编码格式为utf-8
		request.setCharacterEncoding("UTF-8");
		//设置回复编码格式为utf-8
		response.setContentType("text/html;charset=UTF-8");
		response.setCharacterEncoding("UTF-8");
		String destPage = request.getParameter("destPage");
		request.getRequestDispatcher("WEB-INF/"+destPage).forward(request, response);	
		
	}

}
