package com.fashionshopping.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.fashionshopping.model.service.impl.LoginServiceImpl;

public class loginController extends HttpServlet {

	
	public loginController() {
		super();
	}

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
            this.doPost(request, response);
	}

	
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		//设置回复编码格式为utf-8
		response.setContentType("text/html;charset=UTF-8");
		//设置请求编码格式为utf-8
		request.setCharacterEncoding("UTF-8");
		PrintWriter out = response.getWriter();
		String type=request.getParameter("type");
		LoginServiceImpl ls=new LoginServiceImpl();
		if("login".equals(type)){
			 String login=request.getParameter("login");
	         String pass=request.getParameter("pass"); 
	         if(ls.loginConfirm(login, pass)){
	        	request.getRequestDispatcher("WEB-INF/mian/aindex.jsp").forward(request, response);	 
	         }
		}
		
		
	}



}
