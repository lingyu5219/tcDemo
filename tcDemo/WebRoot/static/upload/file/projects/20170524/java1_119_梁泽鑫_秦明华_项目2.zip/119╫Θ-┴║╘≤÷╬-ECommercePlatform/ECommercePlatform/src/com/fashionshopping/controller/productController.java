package com.fashionshopping.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.sf.json.JSONObject;

import com.fashionshopping.model.bean.Category;
import com.fashionshopping.model.bean.Product;
import com.fashionshopping.model.service.impl.CategoryServiceImpl;
import com.fashionshopping.model.service.impl.ProductServiceImpl;

public class productController extends HttpServlet {


	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		this.doPost(request, response);
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		//设置回复编码格式为utf-8
		response.setContentType("text/html;charset=UTF-8");
		//设置请求编码格式为utf-8
		request.setCharacterEncoding("UTF-8");
		PrintWriter out = response.getWriter();
		String type=request.getParameter("type");
		ProductServiceImpl ps=new ProductServiceImpl();
		JSONObject jobj = new JSONObject();
		if("query".equals(type)){//首次分类信息显示
			//得到参数并转为int型
			String s_pageNow=request.getParameter("page");
			String s_pageSize=request.getParameter("rows");
			int pageNow=Integer.parseInt(s_pageNow);
			int pageSize=Integer.parseInt(s_pageSize);
	        ArrayList<Product> result=ps.getByPageAndPagesize(pageNow, pageSize);
	        //得到商品总行数
	        int i=ps.getRowCount();
	        Integer total=Integer.valueOf(i);
	        jobj = new JSONObject();//new一个JSON  
	        jobj.accumulate("total",total);//total代表一共有多少数据  
	        jobj.accumulate("rows", result);//row是代表显示的页的数据  
	        //转化为JSOn格式 
	        out.write(jobj.toString());	      
		}else if("delete".equals(type)){//删除商品功能实现
			String ids=request.getParameter("ids");
			System.out.println(ids);
			Boolean b=ps.deleteProductByIds(ids);
			if(b){
				out.write("success");
			}			
		}else if("getInputProduct".equals(type)){//查询商品功能实现
			String product=request.getParameter("product");
			String s_pageNow=request.getParameter("page");
			String s_pageSize=request.getParameter("rows");
			int pageSize=Integer.parseInt(s_pageSize);
			int pageNow=Integer.parseInt(s_pageNow);
			System.out.println("页面大小  "+pageSize+" 类型  "+product);
			ArrayList<Product> result=ps.getInputProduct(product,pageSize,pageNow);
			int i=ps.getRowCountByInput(product);
	        Integer total=Integer.valueOf(i);
			jobj = new JSONObject();
			jobj.accumulate("total",total);
			jobj.accumulate("rows", result);
			out.write(jobj.toString());
		}else if("showAddProductPage".equals(type)){//显示添加shangpin页面
			request.getRequestDispatcher("WEB-INF/product/productAdd.jsp").forward(request, response);
		}else if("addProduct".equals(type)){//添加商品功能实现
			System.out.println("tttttt");
	        String name=request.getParameter("name");
	        String price=request.getParameter("price");
	        System.out.println(name+"  "+price);
	        
	        
	        
	       
	        out.write("success");
		}else if("showUpdateProductPage".equals(type)){//打开商品修改页面
			request.getRequestDispatcher("WEB-INF/product/productUpdate.jsp").forward(request, response);	
		}else if("updateProduct".equals(type)){//修改商品功能实现
			String ishot=null;
			//获得参数
			String categoryType=request.getParameter("categoryType");
			String hot=request.getParameter("hot");
			if("true".equals(hot)){
				ishot="1";	
			}else{
				ishot="0";
			}
			String accountId=request.getParameter("account.id");
			String id=request.getParameter("id");
			System.out.println(categoryType+"  "+hot+" "+accountId+" "+id);
			String paras[]={categoryType,ishot,accountId,id};
			String sql="update product set =?,=?,=? where id=?";
		    ps.update(sql, paras);
			out.write("success");
		}
		
	}

}
