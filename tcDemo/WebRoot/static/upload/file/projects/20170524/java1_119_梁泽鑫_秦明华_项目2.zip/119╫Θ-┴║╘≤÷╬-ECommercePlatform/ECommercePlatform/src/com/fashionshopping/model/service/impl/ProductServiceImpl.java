package com.fashionshopping.model.service.impl;

import java.util.ArrayList;

import com.fashionshopping.model.bean.Category;
import com.fashionshopping.model.bean.Product;
import com.fashionshopping.model.condb.ConMysql;
import com.fashionshopping.model.service.ProductService;

public class ProductServiceImpl extends BaseServiceImpl<Product> implements ProductService {

	public ProductServiceImpl(){
		super();
	}
	//得到商品集合信息
    public ArrayList<Product> getByPageAndPagesize( int pageNow,int pageSize){
    	ArrayList<Product> result =new ArrayList<Product>();
		try{
            //得到数据库连接
           ConMysql connection=new ConMysql();
           con=connection.getCon();
           String sql="select p.id,p.name,p.price,p.pic,p.remark,p.xremark,p.date,p.commend,p.open,p.cid,c.type from product as p left join category as c on p.cid=c.id limit ?,?";
           ps=con.prepareStatement(sql);
           ps.setInt(1, pageSize*(pageNow-1));
           ps.setInt(2, pageSize);
           rs=ps.executeQuery();
           while(rs.next()){
        	   Product p=new Product();
        	   p.setId(rs.getInt(1));
        	   p.setName(rs.getString(2));
        	   p.setPrice(rs.getDouble(3));
        	   p.setPic(rs.getString(4));
        	   p.setRemark(rs.getString(5));
        	   p.setXremark(rs.getString(6));
        	   p.setDate(rs.getString(7));
        	   p.setCommend(rs.getBoolean(8));
        	   p.setOpen(rs.getBoolean(9));
        	   p.setCid(rs.getInt(10));
        	   p.setType(rs.getString(11));
        	   result.add(p);
           }
          }catch(Exception e){
        	  e.printStackTrace();
          }finally{
        	  this.close();
          }		
		return result;
    }
    //得到商品记录条数（行数）
    public int getRowCount() {
		int rowCount=0;
		try{
			 //得到数据库连接
	        ConMysql connection=new ConMysql();
	        con=connection.getCon();
	        String sql="select count(*) from product";
	        ps=con.prepareStatement(sql); 
	        rs=ps.executeQuery();
	        if(rs.next()){
	        	rowCount=rs.getInt(1);
	        }
       }catch(Exception e){
     	  e.printStackTrace();
       }finally{
     	  this.close();
       }
		return rowCount;
	}  
  //根据id删除类别信息
    public Boolean deleteProductByIds(String ids){
       Boolean b=false;
       System.out.println(ids);
       try{
			 //得到数据库连接
	        ConMysql connection=new ConMysql();
	        con=connection.getCon();
	        String sql="delete from product where id in ("+ids+")";
	        ps=con.prepareStatement(sql); 
	      //ps.setString(1, );
	        int i=ps.executeUpdate();
	        if(i!=0){
	        	b=true;
	        }
      }catch(Exception e){
    	  e.printStackTrace();
      }finally{
    	  this.close();
      }
       return b;	
    }
   //根据输入商品查询商品信息
    public ArrayList<Product> getInputProduct(String Product,int pageSize,int pageNow){
    	   ArrayList<Product> arr=new ArrayList<Product>();
    	   try{
  			 //得到数据库连接
  	        ConMysql connection=new ConMysql();
  	        con=connection.getCon();
  	        String sql="select p.id,p.name,p.remark,p.cid,c.type from product as p left join category as c on p.cid=c.id where p.name like ? limit ?,?";
  	        ps=con.prepareStatement(sql); 
  	        ps.setString(1,"%"+Product+"%");
  	        ps.setInt(2,pageSize*(pageNow-1));
  	        ps.setInt(3,pageSize);
  	        rs=ps.executeQuery();
  	        while(rs.next()){
  	        	Product p=new Product();
  	        	p.setId(rs.getInt(1));
  	        	p.setName(rs.getString(2));
  	        	p.setRemark(rs.getString(3));
  	        	p.setCid(rs.getInt(4));
  	        	p.setType(rs.getString(5));
  	        	arr.add(p);
  	        }
        }catch(Exception e){
      	  e.printStackTrace();
        }finally{
      	   this.close();
        }
    	 return arr;
    }
    //按照查询商品得到行数
    public int getRowCountByInput(String product) {
		int rowCount=0;
		try{
			 //得到数据库连接
	        ConMysql connection=new ConMysql();
	        con=connection.getCon();
	        String sql="select count(*) from product where name like ? ";
	        ps=con.prepareStatement(sql); 
	        ps.setString(1,"%"+product+"%");	        
	        rs=ps.executeQuery();
	        if(rs.next()){
	        	rowCount=rs.getInt(1);
	        }
       }catch(Exception e){
     	  e.printStackTrace();
       }finally{
     	  this.close();
       }
		return rowCount;
	}
    //添加商品方法
    public void addProduct(){
    	try{
			 //得到数据库连接
	        ConMysql connection=new ConMysql();
	        con=connection.getCon();
	        String sql="insert into product() values(?,?,?,?,?,?)";
	        ps=con.prepareStatement(sql); 
	        //ps.setString(1, );	        
	        rs=ps.executeQuery();
	        
      }catch(Exception e){
    	  e.printStackTrace();
      }finally{
    	  this.close();
      }
    }
	
}
