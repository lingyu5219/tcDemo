package com.fashionshopping.model.service;
import com.fashionshopping.model.bean.Account;


public interface AccountService extends BaseService<Account>{

}
