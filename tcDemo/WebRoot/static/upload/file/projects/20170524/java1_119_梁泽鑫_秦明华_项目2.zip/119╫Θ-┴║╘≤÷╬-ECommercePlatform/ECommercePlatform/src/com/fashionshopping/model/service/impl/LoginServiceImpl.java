package com.fashionshopping.model.service.impl;

import com.fashionshopping.model.bean.Account;
import com.fashionshopping.model.condb.ConMysql;

public class LoginServiceImpl extends BaseServiceImpl<Account>{
   public boolean loginConfirm(String username,String pass){
	   Boolean b=false;
	   try{
			 //得到数据库连接
	        ConMysql connection=new ConMysql();
	        con=connection.getCon();
	        String sql="select login from account where login=?";
	        ps=con.prepareStatement(sql); 
	        ps.setString(1, username);
            rs=ps.executeQuery(); 
            if(rs.next()){       //说明在account表中找到用户名
                String sql1="select pass from account where login=? ";
                ps=con.prepareStatement(sql1);//预编译sql语句
                ps.setString(1,username);//给？赋值
                rs=ps.executeQuery(); //执行sql语句    
                if(rs.next()){
                    //进来说明用户名正确
                    if(rs.getString(1).equals(pass)){
                    	 //密码正确，用户合法
                    	b=true;	
                    }
                }
             }
     }catch(Exception e){
   	    e.printStackTrace();
     }finally{
   	    this.close();
     }
	    return b;
   } 
}
