package com.fashionshopping.model.service;

import com.fashionshopping.model.bean.Product;

public interface ProductService extends BaseService<Product> {

}
