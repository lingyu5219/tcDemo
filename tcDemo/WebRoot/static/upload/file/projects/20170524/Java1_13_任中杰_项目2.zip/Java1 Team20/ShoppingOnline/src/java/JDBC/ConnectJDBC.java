/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package JDBC;

import java.sql.Connection;
import java.sql.DriverManager;
/**
 *
 * @author admin
 */
public class ConnectJDBC {
    //配置驱动程序
   public static final String DbDriver="com.mysql.jdbc.Driver"; 
   //配置链接地址
   public static final String DbUrl="jdbc:mysql://localhost:3306/ShoppingOnline?zeroDateTimeBehavior=convertToNull";
   //用户名
   public static final String DbUserName="root";
   //密码
   public static final String DbPassWord="niit";
     
public static Connection ConnectDB(){
      //链接对象
      try
      {
  Connection con= null;
  //加载驱动程序
  Class.forName(DbDriver);
  //连接数据库
   con=DriverManager.getConnection(DbUrl,DbUserName,DbPassWord);  
   return con;
      }
      catch(Exception ex)
      {
      ex.printStackTrace();
      }
   return null;
}   
}
