/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

/**
 *
 * @author niit
 */
@MultipartConfig(location = "D:\\")
public class StoreInfo extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
       private String getFilename(Part part)
    {    
    String contentDispositionHeader=part.getHeader("content-disposition");
    String[] elements=contentDispositionHeader.split(";");
    for(String element:elements){
    if(element.trim().startsWith("filename"))
    {
    return element.substring(element.indexOf('=')+1).trim().replace("\"", "");
    }
    }
    return null;
    }
    
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet StoreInfo</title>");            
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet StoreInfo at " + request.getContextPath() + "</h1>");
            out.println("</body>");
            out.println("</html>");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
     protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
         response.setContentType("text/html;charset=UTF-8");
      request.setCharacterEncoding("UTF-8");
    PrintWriter out = response.getWriter();
    out.println("dsfds");
    PreparedStatement pstmt=null; 
    String store_name=request.getParameter("store_name");
    String icon=request.getParameter("Icon");
    String store_type=request.getParameter("store_type");
    String store_intro=request.getParameter("store_intro");
    String manage_type=request.getParameter("manage_type");
    String main_supply=request.getParameter("main_supply");
    int index=icon.lastIndexOf("\\");
    char[] chr =new char[100];
    icon.getChars(index+1,icon.length(),chr,0);
    String iconname=String.valueOf(chr);
    Part part=request.getPart("Icon");
    String fileName=getFilename(part);
    if(fileName!=null&&!fileName.isEmpty())
    {
    part.write(fileName);
    }
    try
    {
    Connection con=JDBC.ConnectJDBC.ConnectDB();
    pstmt=con.prepareStatement("insert into storesinfo values(?,?,?,?,?,?)");
    pstmt.setString(1,store_name);
    pstmt.setString(2,iconname);
    pstmt.setString(3,store_type);
    pstmt.setString(4,store_intro);
    pstmt.setString(5,manage_type);
    pstmt.setString(6,main_supply);
    pstmt.executeUpdate();
    con.close();
    pstmt.close();
    }catch(Exception ex)
    {
    ex.printStackTrace();
    }
    response.sendRedirect("Home.jsp");
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
