package com.wbb.app.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.wbb.app.model.Product;




public interface ProductMapper {

	public List<Product> getProduct(String id);
	public Product getProduct1(String id);
	public List<Product> getShopProduct(@Param("s_id")String s_id);
	public int getTotalBookNumber();
	public List<Product> getPageList(@Param("pageNo")int pageNo, @Param("pageSize")int pageSize);
	
}
