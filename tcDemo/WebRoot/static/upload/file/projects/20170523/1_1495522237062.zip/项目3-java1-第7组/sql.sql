drop database ECommercePlatform;
create database ECommercePlatform;
ALTER SCHEMA `ecommerceplatform`  DEFAULT COLLATE utf8_bin ;
use ECommercePlatform;
create table category(
	ca_id varchar(10) primary key not null,
	ca_name	varchar(20) not null
);
create table shop(
s_id varchar(10) primary key not null ,
s_name varchar(100) not null
);
create table product(
	p_id varchar(10)  primary key ,
	p_name varchar(100) not null,
    p_describe varchar(100)  null,
    p_price int not null,
    p_image varchar(100) not null,
    p_stock int not null,
    p_brand varchar(20) not null,
    ca_id varchar(20) ,
    s_id varchar(10) not null ,
    foreign key(ca_id) references category(ca_id),
    foreign key(s_id) references shop(s_id)
);
create table user(
	u_id varchar(10) primary key not null,
    u_name varchar(20) not null,
    u_password varchar(20) not null,
	u_phone varchar(11) not null,
    u_email varchar(50) not null,
    u_address varchar(100) not null,
    u_age int not null,
    u_sex varchar(10) not null,
    u_money int not null,
    u_idcart varchar(18) not null ,
    u_position varchar(20) not null,
    p_id varchar(10) null,
    s_id varchar(10)  null,
    foreign key(p_id) references  product(p_id),
    foreign key(s_id) references  shop(s_id)
);
create table secretsecurity(
u_id varchar(10) primary key,
question1 varchar(100) not null,
question2 varchar(100) not null,
question3 varchar(100) not null,
answer1 varchar(100) not null,
answer2 varchar(100) not null,
answer3 varchar(100) not null,
foreign key(u_id) references user(u_id)
);
create table buydetails(
	bd_id  int   primary key  AUTO_INCREMENT ,
    bd_request varchar(100) not null,
    bd_state varchar(10) not null,
    bd_confirm varchar(10) not null,
    bd_delivery varchar(10) not null,
    bd_comment varchar(10) not null,
    bd_date varchar(20) not null,
    bd_quantity int not null,
    bd_cost int not null,
    bd_name varchar(20) not null,
	bd_phone varchar(11) not null,
	bd_address varchar(100) not null, 
    u_id varchar(10) not null,
    p_id varchar(10) not null,
	foreign key(u_id) references  user(u_id),
    foreign key(p_id) references  product(p_id)
);
create table comment(
e_id  int   primary key  AUTO_INCREMENT,
e_comment varchar(100),
e_starRating int,
bd_id int,
foreign key(bd_id) references  buydetails(bd_id)
);
create table receiptAddress(
ra_id int primary key auto_increment,
ra_name varchar(20) not null,
ra_phone varchar(11) not null,
ra_address varchar(100) not null,
u_id varchar(10)not null,
foreign key(u_id) references  user(u_id)
);
insert into shop values('s1','中国移动手机官方旗舰店 '),('s2','中国最大鞋店'),('s3','三只松鼠旗舰店'),('s4','中国最大电脑店'),('s5','中国最大衣服店'),('s6','中国最大家具店');
insert into category values('c1','phone'),('c2','computer'),('c3','clothes'),('c4','snacks'),('c5','shoes'),('c6','furniture');
insert into product values
('p1','iphone7','',5388,'images/a11.jpg',1111,'iphone','c1','s1'),
('p2','Xiaomi/小米 小米手机5s 4g大屏智能超声波指纹解锁金属拍照手机','',1999	,'images/a21.jpg',1111,'xiaomi','c1','s1'),
('p3','【玫瑰金新色上市 抢先收藏】Huawei/华为 nova 4G智能手机','',2399,'images/a31.jpg',1111,'huawei','c1','s1'),
('p4','[立减600+领300红包]Samsung/三星 Galaxy S7 Edge SM-G9350手机','',5688,'images/a41.jpg',1111,'Samsung','c1','s1'),
('p5','【直降300元】OPPO R9全网通正面指纹识别新款智能拍照4G手机oppo','',2499,'images/a51.jpg',1111,'phone','c1','s1'),
('p6','Asus/华硕 X555YI 7110-554LXFA2X10四核独显手提游戏笔记','',2699,'images/b11.jpg',1111,'Asus','c2','s4'),
('p7','Hasee/神舟 战神 Z7-SL7 D3 4核六代CPU GTX970M独显游戏本笔记本','',6799,'images/b21.jpg',1111,'Hasee','c2','s4'),
('p8','Dell/戴尔 灵越15(7559) Ins15P-2749 i7四核笔记本游戏本 ','',7099,'images/b31.jpg',1111,'Dell','c2','s4'),
('p9','Lenovo/联想 拯救者15-ISK i7悦动版','',6299,'images/b41.jpg',1111,'Lenovo','c2','s4'),
('p10','Acer/宏碁 F5 572G i5六代 GT940M独显 15.6英寸游戏笔记本电脑','',3499,'images/b51.jpg',1111,'Acer','c2','s4'),
('p11','春秋季男士长袖t恤青年秋衣体恤上衣秋装男装潮男男款日系打底衫','',99,'images/c11.jpg',1111,'no','c3','s5'),
('p12','2016秋冬季新款男士衬衫长袖衬衣纯棉商务修身型加绒保暖衣服男装','',149,'images/c21.jpg',1111,'no','c3','s5'),
('p13','GXG男装 冬季热卖韩版修身休闲棒球服夹克男青年外套男','',379,'images/c31.jpg',1111,'no','c3','s5'),
('p14','F21男友风格纹宽松长袖衬衫 FOREVER21女装','',169,'images/c41.jpg',1111,'no','c3','s5'),
('p15','拉夏贝尔 7m莫丽菲尔2016秋新款立领短款棒球服外套女','',221,'images/c51.jpg',1111,'no','c3','s5'),
('p16','秋冬季真皮男鞋商务正装牛皮皮鞋男士休闲鞋软底鞋子中老年爸爸鞋','',88,'images/D11.jpg',1000,'Qimtmsquan','c5','s2'),
('p17','鸿星尔克正品男鞋休闲鞋时尚百搭运动鞋防滑耐磨滑板鞋','',109,'images/D21.jpg',1000,'Qimtmsquan','c5','s2'),
('p18','2016英伦女鞋中跟休闲鞋粗跟单鞋女春秋厚底鞋坡跟松糕真皮小皮鞋','',219,'images/D31.jpg',1000,'Qimtmsquan','c5','s2'),
('p19','盾狐2016秋冬季新款潮粗跟单鞋女高跟鞋防水台深口韩版圆头女鞋子','',168,'images/D41.jpg',1000,'Qimtmsquan','c5','s2'),
('p20','2016潮秋冬加绒马丁靴厚底女鞋短筒雪地靴粗跟高跟短靴防水台女鞋','',219,'images/D51.jpg',1000,'Qimtmsquan','c5','s2'),
 ('p21','天天特价】圣维拉燕麦巧克力500g营养麦片巧克力棒喜糖果零食品','',13,'images/E11.jpg',1000,'Qimtmsquan','c4','s3'),
('p22','【三只松鼠_猪肉猪肉脯210g】休闲食品零食小吃靖江特产猪肉干','',14,'images/E21.jpg',1000,'Qimtmsquan','c4','s3'),
('p23','【三只松鼠_小贱五香猪肉粒210g】休闲食品零食小吃猪肉干','',15,'images/E31.jpg',1000,'Qimtmsquan','c4','s3'),
('p24','银城湘味香辣卤鸭掌20包/40包湖南鸭掌 鸭爪特产零食小吃真空包装','',19,'images/E41.jpg',1000,'Qimtmsquan','c4','s3'),
('p25','葡记蒸蛋糕奶香1kg整箱零食品 手撕面包子口袋糕点心蒸三明治早餐','',29,'images/E51.jpg',1000,'Qimtmsquan','c4','s3'),
('p26','包送货 全实木家具松木衣柜 成人儿童234门组合木质简易大衣橱','',39,'images/F11.jpg',1000,'Qimtmsquan','c6','s6'),
('p27','创意原木北欧宜家餐桌实木餐桌椅组合白橡木餐厅一桌六椅家具','',2990,'images/F21.jpg',1000,'Qimtmsquan','c6','s6'),
('p28','柏斯町真皮沙发头层牛皮组合现代小大户型客厅中厚皮沙发皮艺少发','',5990,'images/F31.jpg',1000,'Qimtmsquan','c6','s6'),
('p29','原始原素简约现代白橡木纯全实木家具实木床头柜边柜角柜储物柜子','',780,'images/F41.jpg',1000,'Qimtmsquan','c6','s6'),
('p30','源氏木语北欧全实木橡木电视柜1.8米简约现代地柜客厅带抽屉家具','',99,'images/F51.jpg',1000,'Qimtmsquan','c6','s6');
insert into user values('u12345','Albert','abc123',13011011111,'1@qq.com','Qingdao',20,'male',100000,'330327199511111111','customer','p1',null);
insert into user values('u12346','Albert','abc123',13011011111,'1@qq.com','Qingdao',20,'male',100000,'330327199511111111','customer','p1','s1');
insert into receiptAddress(ra_name,ra_phone,ra_address,u_id) values('吴斌斌','15066811111','山东省 青岛市 市南区 香港中路街道	宁夏路308号青岛大学西院汇园2','u12345')



insert into buydetails(bd_request,bd_state,bd_confirm,bd_delivery,bd_evaluate,bd_date,bd_quantity,bd_cost,bd_name,bd_phone,bd_address,u_id,p_id)
 values('i want to buy ...','true','false','false','false','2016-12-14',2,2000,'Albert','15066815079','山东省 青岛市 市南区 香港中路街道	宁夏路308号青岛大学西院汇园2','u12345','p1')
select * from product p join category c on p.ca_id=c.ca_id;
select * from user u left join shop s on u.s_id=s.s_id where u_id='u12346';
select count(p_id) from product
select * from product p join category c on  p.ca_id=c.ca_id LIMIT 0, 6;
select * from product p join category c on  p.ca_id=c.ca_id join shop s on p.s_id=s.s_id where p_id='p1'
SELECT * FROM buydetails b join product p on b.p_id=p.p_id join shop s on p.s_id=s.s_id   where p.s_id='s1' and bd_state='true' and bd_confirm='false'
SELECT * FROM buydetails b join product p on b.p_id=p.p_id join shop s on p.s_id=s.s_id join comment c on b.bd_id=c.bd_id where p.p_id='p4'
SELECT * FROM buydetails b join product p on b.p_id=p.p_id join shop s on p.s_id=s.s_id  where bd_id=2