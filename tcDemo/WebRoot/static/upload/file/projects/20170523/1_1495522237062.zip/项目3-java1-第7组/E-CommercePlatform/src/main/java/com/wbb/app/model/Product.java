
package com.wbb.app.model;


public class Product {

    private String id;
    private String name;
    private String describe;
    private int price;
    private String image;
    private int stock;
    private String brand;
    private Category category;
    private Shop shop;
    
    public String getId() {
        return id;
    }
    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescribe() {
        return describe;
    }

    public void setDescribe(String describe) {
        this.describe = describe;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public int getStock() {
        return stock;
    }

    public void setStock(int stock) {
        this.stock = stock;
    }

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public Category getCategory() {
        return category;
    }

    public void setCategory(Category category) {
        this.category = category;
    }

    public Shop getShop() {
        return shop;
    }

    public void setShop(Shop shop) {
        this.shop = shop;
    }

    
    public Product(String id, String name, String describe, int price, String image, int stock, String brand, Category category) {
        this.id = id;
        this.name = name;
        this.describe = describe;
        this.price = price;
        this.image = image;
        this.stock = stock;
        this.brand = brand;
        this.category = category;
    }

    public Product(String id, String name, String describe, int price, String image, int stock, String brand) {
        this.id = id;
        this.name = name;
        this.describe = describe;
        this.price = price;
        this.image = image;
        this.stock = stock;
        this.brand = brand;
    }

    public Product(String id, String name, String describe, int price, String image, int stock, String brand, Category category, Shop shop) {
        this.id = id;
        this.name = name;
        this.describe = describe;
        this.price = price;
        this.image = image;
        this.stock = stock;
        this.brand = brand;
        this.category = category;
        this.shop = shop;
    }
   
    public Product() {
    }
    
	public Product(String id) {
		super();
		this.id = id;
	}
	@Override
	public String toString() {
		return "Product [id=" + id + ", name=" + name + ", describe=" + describe + ", price=" + price + ", image="
				+ image + ", stock=" + stock + ", brand=" + brand + ", category=" + category + ", shop=" + shop + "]";
	}
    
}
