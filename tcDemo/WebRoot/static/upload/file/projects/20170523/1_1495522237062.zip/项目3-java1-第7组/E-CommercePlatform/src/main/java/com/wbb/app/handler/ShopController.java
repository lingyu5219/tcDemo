package com.wbb.app.handler;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.google.gson.Gson;
import com.wbb.app.dao.ProductMapper;
import com.wbb.app.dao.ShopMapper;
import com.wbb.app.model.Product;
import com.wbb.app.service.ProductService;

@Controller
public class ShopController {

	@Resource
	ProductMapper productMapper;
	@Resource
	ShopMapper shopMapper;
	@Resource
	HttpServletRequest request;
	@Resource
	ProductService productService;
	
	@ResponseBody
	@RequestMapping("getAllProduct")
	public String getAllProduct() {
		String s_id = (String) request.getSession().getAttribute("s_id");
		List<Product> products = productMapper.getShopProduct(s_id);
		System.out.println(products);
		Gson gson = new Gson();
		String jsonStr = gson.toJson(products);
		return jsonStr;
	}

	@ResponseBody
	@RequestMapping(value="/addProduct",produces = "application/json;charset=UTF-8")
	public String addProduct() {

		String s_id = (String) request.getSession().getAttribute("s_id");
		System.out.println("s_id"+s_id);
		String name=request.getParameter("name");
		String price=request.getParameter("price");
		String stock=request.getParameter("stock");
		String brand=request.getParameter("brand");
		String image=request.getParameter("image");
		String p_id="";
		 boolean b;
		while(true){
			    p_id = productService.getPid();
	            b = productService.checkPid(s_id, p_id);
	            System.out.println("boolean:" + b);
	            if (b == true) {
	            	shopMapper.addProduct(new Product(p_id,name,"",Integer.parseInt(price),image,Integer.parseInt(stock),brand), null, s_id);
	            } 
                break;
		}
		Gson gson = new Gson();
		String jsonStr = gson.toJson("true");
		return jsonStr;
	}
	@ResponseBody
	@RequestMapping(value="/editProduct",produces = "application/json;charset=UTF-8")
	public String editProduct(){
		String p_id=request.getParameter("id");
		String name=request.getParameter("name");
		String price=request.getParameter("price");
		String stock=request.getParameter("stock");
		String brand=request.getParameter("brand");
		String image=request.getParameter("image");
		shopMapper.updateProduct(new Product(p_id,name,"",Integer.parseInt(price),image,Integer.parseInt(stock),brand));
		System.out.println("id:"+p_id);
		Gson gson = new Gson();
		String jsonStr = gson.toJson("true");
		return jsonStr;
	}
	
	@ResponseBody
	@RequestMapping(value="/deleteProduct",produces = "application/json;charset=UTF-8")
	public String deleteProduct(Map<String, Object>map){
		
		String p_id=request.getParameter("id");
		shopMapper.deleteProduct(p_id);
		System.out.println(p_id);
		map.put("success", "true");
		Gson gson = new Gson();
		String jsonStr = gson.toJson(map);
		return jsonStr;
	}
	
	@RequestMapping(value="/delivery")
	public String delivery(Map<String, Object>map){
		System.out.println("delivery");
		String bd_id=request.getParameter("id");
		shopMapper.delivery(bd_id, "true");
		System.out.println(bd_id);
		return "ManageShop1";
		
	}
	

}
