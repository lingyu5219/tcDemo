/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.wbb.app.model;

import java.util.Date;


/**
 *
 * @author AlbertPC
 */
public class BuyDetails {
   
    private String request;
    private String state;
    private String confirm;
    private String delivery;
    private String comment;
    private String date;
    private int quantity;
    private int cost;
    private String name;
   	private String phone ;
   	private String address;
    private String u_id;
    private String p_id;
	
	public String getRequest() {
		return request;
	}

	public void setRequest(String request) {
		this.request = request;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getConfirm() {
		return confirm;
	}

	public void setConfirm(String confirm) {
		this.confirm = confirm;
	}
	
	public String getDelivery() {
		return delivery;
	}

	public void setDelivery(String delivery) {
		this.delivery = delivery;
	}

	public String getcomment() {
		return comment;
	}

	public void setcomment(String comment) {
		this.comment = comment;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public int getCost() {
		return cost;
	}

	public void setCost(int cost) {
		this.cost = cost;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getU_id() {
		return u_id;
	}

	public void setU_id(String u_id) {
		this.u_id = u_id;
	}

	public String getP_id() {
		return p_id;
	}

	public void setP_id(String p_id) {
		this.p_id = p_id;
	}


	public BuyDetails(String request, String state, String confirm, String delivery, String comment, String date,
			int quantity, int cost, String name, String phone, String address, String u_id, String p_id) {
		super();
		this.request = request;
		this.state = state;
		this.confirm = confirm;
		this.delivery = delivery;
		this.comment = comment;
		this.date = date;
		this.quantity = quantity;
		this.cost = cost;
		this.name = name;
		this.phone = phone;
		this.address = address;
		this.u_id = u_id;
		this.p_id = p_id;
	}

	public BuyDetails() {
		super();
	}
    
    
    
}
	
