package com.wbb.app.service;



import java.util.List;
import java.util.Random;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Service;

import com.wbb.app.dao.ProductMapper;
import com.wbb.app.model.Page;
import com.wbb.app.model.Product;
import com.wbb.app.model.ShoppingCart;
@Service
public class ProductService {

	@Resource
	ProductMapper productMapper;
	
	 public Product getProduct(String id) {
		  Product product = productMapper.getProduct1(id);
	        return product;
	        }
	 public Page<Product> getPage(int pageNo) {
		 int pageSize=8;
	        Page<Product> page = new Page<>(pageNo);
	        page.setTotalItemNumber(productMapper.getTotalBookNumber());
	        pageNo = page.getPageNo();
	        pageNo=(pageNo - 1) * pageSize;
	        page.setList(productMapper.getPageList(pageNo, pageSize));
	        return page;
	    }
	 public ShoppingCart getShoppingCart(HttpServletRequest request) {
	        HttpSession session = request.getSession();

	        ShoppingCart sc = (ShoppingCart) session.getAttribute("ShoppingCart");
	        if (sc == null) {
	            sc = new ShoppingCart();
	            session.setAttribute("ShoppingCart", sc);
	        }

	        return sc;
	    }
	 public boolean addToCart(String id, ShoppingCart sc) {
	        Product product = getProduct(id);

	        if (product != null) {
	            sc.addProduct(product);
	            return true;
	        }
	        return false;
	    }

	    public void removeItemFromShoppingCart(ShoppingCart sc, String id) {
	        sc.removeItem(id);
	    }

	    public void clearShoppingCart(ShoppingCart sc) {
	        sc.clear();
	    }

	    public void updateItemQuantity(ShoppingCart sc, String id, int quantity) {
	        sc.updateItemQuantity(id, quantity);
	    }
	    public String getPid() {
	        Random random = new Random();
	        int a = random.nextInt(10000);
	        String p_id = "p" + a;
	        return p_id;
	    }

	    public boolean checkPid(String s_id, String p_id) {
	      
	        boolean b = true;

	            List<Product> products =productMapper.getShopProduct(s_id);
	            	for(Product p:products){
	            		 if (p.getId().equalsIgnoreCase(p_id)) {
	 	                    b = false;
	 	                   break;
	 	                }
	 	               continue;
	            	} 
	        return b;
	    }

	    
}
