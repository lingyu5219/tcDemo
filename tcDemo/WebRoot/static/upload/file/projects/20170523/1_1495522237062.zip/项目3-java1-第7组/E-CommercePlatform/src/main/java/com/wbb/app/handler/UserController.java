package com.wbb.app.handler;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.google.gson.Gson;
import com.wbb.app.dao.ProductMapper;
import com.wbb.app.dao.UserMapper;
import com.wbb.app.model.Page;
import com.wbb.app.model.Product;
import com.wbb.app.model.Secretsecurity;
import com.wbb.app.model.User;
import com.wbb.app.service.ProductService;

@Controller
public class UserController {

	@Resource
	UserMapper userMapper;

	@Resource
	HttpSession session;

	@Resource
	ProductMapper productMapper;

	@Resource
	ProductService productService;
	@Resource
	HttpServletRequest request;
	@Resource
	HttpServletResponse response;

	@RequestMapping("login")
	public String login(@RequestParam("id") String id, @RequestParam("password") String password,
			@RequestParam("radio") String radio) {
		System.out.println(id);
		User user = userMapper.getUserByID(id);
		System.out.println(user);
		if (password.equalsIgnoreCase(user.getPassword())) {
			session.setAttribute("position", radio);
			session.setAttribute("username", user.getName());
			session.setAttribute("password", user.getPassword());
			session.setAttribute("id", id);
			session.setAttribute("user", user);
			if (user.getShop() != null) {
				System.out.println(user.getShop().getId());
				session.setAttribute("s_id", user.getShop().getId());
			}
			session.setMaxInactiveInterval(6000);
			return "homePage";
		} else {
			return "login";
		}

	}

	@ResponseBody
	@RequestMapping(value = "/checkID", produces = "application/json;charset=UTF-8")
	public String checkID(@RequestParam("id") String id, Map<String, Object> map) throws Exception {
		System.out.println(id);
		List<User> user = userMapper.getUser();
		List<String> list = new ArrayList<>();
		for (User u : user) {
			System.out.println(u.getId());
			list.add(u.getId());
		}
		if (list.contains(id)) {
			map.put("checkID", "�������Ѿ�����");
		} else {
			map.put("checkID", "�����ֿ�����");
		}
		Gson gson = new Gson();
		String jsonStr = gson.toJson(map);
		return jsonStr;
	}

	@RequestMapping("/register")
	public String register(User user) {
		System.out.println("User:" + user);
		userMapper.register(user);
		return "afterRegister";
	}

	@RequestMapping("/logout")
	public String logout() {

		session.removeAttribute("position");
		session.removeAttribute("username");
		session.removeAttribute("id");
		session.removeAttribute("user");
		session.removeAttribute("s_id");
		return "homePage";
	}

	@RequestMapping("/ShowAllGoods")
	public String showAllGoods(Map<String, Object> map) {

		int count = productMapper.getTotalBookNumber();
		System.out.println(count);

		int pageNo = 1;
		String pageNoStr = request.getParameter("pageNo");
		try {
			pageNo = Integer.parseInt(pageNoStr);
		} catch (NumberFormatException e) {
		}
		System.out.println("pageNo:" + pageNo);

		Page<Product> page = productService.getPage(pageNo);

		map.put("productPage", page);
		System.out.println(page);
		return "showGoods";
	}

	@RequestMapping("/showDetails")
	public String showlDetails(Map<String, Object> map) {
		String p_id = request.getParameter("p_id");
		System.out.println(p_id);
		List<Product> product = productMapper.getProduct(p_id);
		System.out.println(product);
		map.put("details", product);
		map.put("p_id", p_id);
		return "showDetails";
	}

	@RequestMapping("/confirm")
	public String confirm() {
		String id = request.getParameter("id");
		userMapper.confirm(id, "true");
		System.out.println(id);
		return "myOrder4";
	}

	@RequestMapping("/comment")
	public String comment() {
		String bd_id = request.getParameter("bd_id");
		String p_id = request.getParameter("p_id");
		System.out.println(bd_id);
		System.out.println(p_id);
		session.setAttribute("bd_id", bd_id);
		return "comment";
	}

	@RequestMapping("submitComment")
	public String submitComment(Map<String, Object> map) {
		String star = request.getParameter("star");
		String comment = request.getParameter("comment");
		String bd_id = (String) request.getSession().getAttribute("bd_id");

		System.out.println("id" + bd_id);
		System.out.println("star:" + star);
		System.out.println(comment);
		userMapper.comment(comment, star, bd_id);
		userMapper.comment1("true", bd_id);
		return "myOrder1";
	}

	@RequestMapping("delete")
	public String delete() {
		String ra_id = request.getParameter("ra_id");
		System.out.println(ra_id);
		userMapper.deleteAddress(ra_id);
		return "receiptAddress";
	}

	@RequestMapping("/modifyUser")
	public String modify() {
		String id = (String) session.getAttribute("id");
		String name = request.getParameter("name");
		String phone = request.getParameter("phone");
		String age = request.getParameter("age");
		String sex = request.getParameter("sex");
		String email = request.getParameter("email");
		String idcart = request.getParameter("idcart");
		String address = request.getParameter("address");
		userMapper.modifyUser(new User(id, name, phone, email, address, Integer.parseInt(age), sex, idcart));
		return "modifyPersonalInformation";
	}

	@RequestMapping("/changePassword")
	public String changePassword() {
		String u_id = (String) session.getAttribute("id");
		String newpassword = request.getParameter("p2");
		userMapper.changePassword(u_id, newpassword);
		session.setAttribute("ChangeMessage", "Update Successful!!!Please login again");
		session.removeAttribute("username");
		session.removeAttribute("id");
		return "changePassword";
	}

	@RequestMapping("SetSecretSecurity")
	public String SetSecretSecurity() {
		String u_id = (String) session.getAttribute("id");
		String id = userMapper.getSecretSecurity(u_id);
		System.out.println("id:" + id);
		String question1 = request.getParameter("question1");
		String question2 = request.getParameter("question2");
		String question3 = request.getParameter("question3");
		String answer1 = request.getParameter("answer1");
		String answer2 = request.getParameter("answer2");
		String answer3 = request.getParameter("answer3");
		
		if (id != null) {
			userMapper.setSecretSecurity1(
					new Secretsecurity(u_id, question1, question2, question3, answer1, answer2, answer3));
			System.out.println("update");
		} else {
			System.out.println("insert");
			userMapper.setSecretSecurity(
					new Secretsecurity(u_id, question1, question2, question3, answer1, answer2, answer3));
		}
		session.setAttribute("setMessage", "Set Secret Security successful!");
		return "secretSecuritySettings";

	}

	@RequestMapping("retrievePassword")
	public String retrievePassword() {
		String u_id = request.getParameter("id");
		String id = userMapper.getSecretSecurity(u_id);
		System.out.println("id:" + id);
		String question1 = request.getParameter("question1");
		String question2 = request.getParameter("question2");
		String question3 = request.getParameter("question3");
		String answer1 = request.getParameter("answer1");
		String answer2 = request.getParameter("answer2");
		String answer3 = request.getParameter("answer3");
		 boolean b = false;
		 String password="";
		if (id != null) {
			Secretsecurity secretsecurity=userMapper.getSecretSecurity1(u_id);
			if(question1.equalsIgnoreCase(secretsecurity.getQuestion1()) && question2.equalsIgnoreCase(secretsecurity.getQuestion2())
                    && question3.equalsIgnoreCase(secretsecurity.getQuestion3()) && answer1.equalsIgnoreCase(secretsecurity.getAnswer1())
                    && answer2.equalsIgnoreCase(secretsecurity.getAnswer2()) && answer3.equalsIgnoreCase(secretsecurity.getAnswer3()))
			{
				  b = true;
			}
		} else {
			session.setAttribute("RetrieveMessage", "��û�����ù��ܱ�");
		}
		if(b==true){
			User user=userMapper.getUserByID(id);
			password=user.getPassword();
			System.out.println(password);
			session.setAttribute("RetrieveMessage", "Your password is:"+password); 
		}
		else{
			session.setAttribute("RetrieveMessage", "Please choose the true question and enter the true password!"); 
		}
		
		return "RetrievePassword";

	}
}
