
/**
* Project Name:video
* File Name:AccountServiceImpl.java
* Package Name:com.niit.demo.service.impl
* Date:2017年2月27日下午1:31:33
* Copyright (c) 2017, Tony All Rights Reserved.
*
*/

package com.niit.demo.service.impl;

import javax.servlet.http.HttpSession;

import com.niit.demo.bean.Account;
import com.niit.demo.dao.IAccountDao;
import com.niit.demo.dao.impl.AccountDaoImpl;
import com.niit.demo.service.IAccountService;
import com.sun.org.apache.bcel.internal.generic.NEW;

/**
* ClassName:AccountServiceImpl <br/>
* Function: TODO ADD FUNCTION. <br/>
* Reason: TODO ADD REASON. <br/>
* Date: 2017年2月27日 下午1:31:33 <br/>
* @author Tony
* @version
* @see
*/
public class AccountServiceImpl implements IAccountService {
	IAccountDao accountDao = new AccountDaoImpl();
	
	@Override
	public boolean addAccount(Account account) throws Exception {
		//如果密码相同 才会保存到数据库中
		if (account.getPassword().equals(account.getConfirmPassword())) {
			int rs = accountDao.addAccount(account);
			return true;
		} else {
			return false;
		}

	}

	@Override
	public boolean checkAccount(HttpSession session, String username, String password) throws Exception {
		
		Account account = accountDao.getAccount(username);
		if (null != account && account.getPassword().equals(password)) {
			session.setAttribute("account", account);
			return true;
		} else {
			return false;
		}
		
	}

}

