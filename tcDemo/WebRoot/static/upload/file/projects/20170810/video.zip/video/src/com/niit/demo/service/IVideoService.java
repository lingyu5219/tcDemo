
/**
* Project Name:video
* File Name:IVideoService.java
* Package Name:com.niit.demo.service
* Date:2017年2月23日下午2:52:43
* Copyright (c) 2017, Tony All Rights Reserved.
*
*/

package com.niit.demo.service;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import com.niit.demo.bean.Video;

/**
* ClassName:IVideoService <br/>
* Function: TODO ADD FUNCTION. <br/>
* Reason: TODO ADD REASON. <br/>
* Date: 2017年2月23日 下午2:52:43 <br/>
* @author Tony
* @version
* @see
*/
public interface IVideoService {
	public List<Video> getVideoList() throws Exception;

	public List<Video> getVideoList(int accountId) throws Exception;
	
	public List<Video> getVideoList(Video video) throws Exception;
	
	public boolean delVideo(int id) throws Exception;
	
	public boolean addVideo(HttpServletRequest request) throws Exception;
	
	public boolean updateVideo(HttpServletRequest request) throws Exception;
	
	public Video getVideo(int id) throws Exception;
	
}

