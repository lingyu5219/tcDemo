
/**
* Project Name:video
* File Name:AuthorFilter.java
* Package Name:com.niit.demo.filter
* Date:2017年3月1日下午1:48:16
* Copyright (c) 2017, Tony All Rights Reserved.
*
*/

package com.niit.demo.filter;

import java.io.IOException;
import java.util.HashMap;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.niit.demo.bean.Account;
import com.niit.demo.bean.Authority;
import com.niit.demo.util.AuthorUtil;

/**
* ClassName:AuthorFilter <br/>
* Function: TODO ADD FUNCTION. <br/>
* Reason: TODO ADD REASON. <br/>
* Date: 2017年3月1日 下午1:48:16 <br/>
* @author Tony
* @version
* @see
*/
@WebFilter(filterName="F2_AuthorFilter",urlPatterns="/*")
public class AuthorFilter implements Filter {

	@Override
	public void destroy() {

		// TODO Auto-generated method stub

	}

	@Override
	public void doFilter(ServletRequest req, ServletResponse res, FilterChain chain)
			throws IOException, ServletException {
		HttpServletRequest request = (HttpServletRequest)req;
		HttpServletResponse response = (HttpServletResponse)res;
		
		String url = request.getServletPath();
		
		HttpSession session = request.getSession();
		Account account = (Account)session.getAttribute("account");
		
		//1.当前url是否在权限表中配置过，权限表中没有当前url 说明当前url不需要限制，允许继续访问
		HashMap<String,Authority> authorMap = AuthorUtil.getAuthorityMap();
		if (!authorMap.containsKey(url)) {
			chain.doFilter(req, res);
		} else {
			/*
			 * 2.如果权限表中有当前url 说明当前url是需要限制的，需要继续判断有没有登录
			 *  如果没有登录，则不允许访问
			 */
			if(null == account) {
				request.getRequestDispatcher("/WEB-INF/jsp/noAuthority.jsp").forward(request, response);
				return;
			} else {
				/*
				 * 3.如果权限表中有当前url 说明当前url是需要限制的，需要继续判断有没有登录
				 *  如果登录了，需要继续判断当前登录用户的角色是否包含在当前url的角色中
				 *  如果包含，说明当前用户可以访问当前url
				 */
				String accountRole = account.getRole();
				Authority authority = authorMap.get(url);
				String authorityRoles = authority.getRoles();
				
				if (authorityRoles.contains(accountRole)){
					chain.doFilter(req, res);
				} else {
					/*
					 * 4.如果权限表中有当前url 说明当前url是需要限制的，需要继续判断有没有登录
					 *  如果登录了，需要继续判断当前登录用户的角色是否包含在当前url的角色中
					 *  如果没有包含，说明当前用户不可以访问当前url
					 */
					
					request.getRequestDispatcher("/WEB-INF/jsp/noAuthority.jsp").forward(request, response);
					return;
				}
			}
		}
	}

	@Override
	public void init(FilterConfig arg0) throws ServletException {

		// TODO Auto-generated method stub

	}

}

