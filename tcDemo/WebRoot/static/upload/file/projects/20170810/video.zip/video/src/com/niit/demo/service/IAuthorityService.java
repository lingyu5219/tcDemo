
/**
* Project Name:video
* File Name:IAuthorityService.java
* Package Name:com.niit.demo.service
* Date:2017年3月1日下午2:18:38
* Copyright (c) 2017, Tony All Rights Reserved.
*
*/

package com.niit.demo.service;

import java.util.List;

import com.niit.demo.bean.Account;
import com.niit.demo.bean.Authority;

/**
* ClassName:IAuthorityService <br/>
* Function: TODO ADD FUNCTION. <br/>
* Reason: TODO ADD REASON. <br/>
* Date: 2017年3月1日 下午2:18:38 <br/>
* @author Tony
* @version
* @see
*/
public interface IAuthorityService {
	public List<Authority> getAuthorityList(Account account) throws Exception;
}	

