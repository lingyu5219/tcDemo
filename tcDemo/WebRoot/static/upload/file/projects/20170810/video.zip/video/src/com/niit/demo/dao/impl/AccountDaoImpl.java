
/**
* Project Name:video
* File Name:AccountDaoImpl.java
* Package Name:com.niit.demo.dao.impl
* Date:2017年2月27日下午1:44:10
* Copyright (c) 2017, Tony All Rights Reserved.
*
*/

package com.niit.demo.dao.impl;

import java.sql.Connection;
import java.sql.ResultSet;

import com.niit.demo.bean.Account;
import com.niit.demo.dao.IAccountDao;
import com.niit.demo.util.DbManager;

/**
* ClassName:AccountDaoImpl <br/>
* Function: TODO ADD FUNCTION. <br/>
* Reason: TODO ADD REASON. <br/>
* Date: 2017年2月27日 下午1:44:10 <br/>
* @author Tony
* @version
* @see
*/
public class AccountDaoImpl implements IAccountDao {

	@Override
	public int addAccount(Account account) throws Exception {
		StringBuffer sql = new StringBuffer("insert into account(username,password) values('")
				.append(account.getUsername())
				.append("','")
				.append(account.getPassword())
				.append("')");
		
		return DbManager.executeUpdate(sql.toString());
		
	}

	@Override
	public Account getAccount(String username) throws Exception {
		StringBuffer sql = new StringBuffer("select * from account where username = '")
				.append(username)
				.append("'");
		Connection conn = DbManager.getConnection();
		ResultSet rs = DbManager.executeQuery(conn, sql.toString());
		Account account = null;
		while(rs.next()){
			account = new Account();
			account.setId(rs.getInt("id"));
			account.setUsername(rs.getString("username"));
			account.setPassword(rs.getString("password"));
			account.setRole(rs.getString("role"));
		}
		conn.close();
		
		return account;
		
	}

}

