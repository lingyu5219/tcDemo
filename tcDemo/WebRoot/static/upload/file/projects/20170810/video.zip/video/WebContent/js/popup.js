function popup(id){
	//弹出层
	var popupDiv = document.getElementById(id);
	popupDiv.style.display = 'block';
	
	//关闭按钮
	var closeBtn = document.createElement("a");
	closeBtn.id = id + "_clostBtn";
	closeBtn.className = "closeBtn";
	closeBtn.href = "javascript:closePopup('"+id+"')";
	closeBtn.innerHTML = "&times;";
	popupDiv.appendChild(closeBtn);
	
	//遮罩层
	var popupBg = document.createElement("div");
	popupBg.id = id + "_popupBg";
	popupBg.className = "video-popup-bg";
	popupBg.style.display = 'block';
	document.body.appendChild(popupBg);
}

function closePopup(id){
	var popupDiv = document.getElementById(id);
	popupDiv.style.display = 'none';
	
	var closeBtn = document.getElementById(id + "_clostBtn");
	popupDiv.removeChild(closeBtn);

	var popupBgDiv = document.getElementById(id + "_popupBg");
	document.body.removeChild(popupBgDiv);
}
