
/**
* Project Name:video
* File Name:ILogService.java
* Package Name:com.niit.demo.service
* Date:2017年2月23日上午10:00:19
* Copyright (c) 2017, Tony All Rights Reserved.
*
*/

package com.niit.demo.service;

import java.sql.SQLException;
import java.util.List;


/**
* ClassName:ILogService <br/>
* Function: TODO ADD FUNCTION. <br/>
* Reason: TODO ADD REASON. <br/>
* Date: 2017年2月23日 上午10:00:19 <br/>
* @author Tony
* @version
* @see
*/
public interface ILogService {
	public int addLog(int account_id,String log_desc) throws Exception;
	
	//public List<Log> getLogs(String account_name) throws SQLException;
}

