
/**
* Project Name:video
* File Name:AuthorityServiceImpl.java
* Package Name:com.niit.demo.service.impl
* Date:2017年3月1日下午2:19:51
* Copyright (c) 2017, Tony All Rights Reserved.
*
*/

package com.niit.demo.service.impl;

import java.util.List;

import com.niit.demo.bean.Account;
import com.niit.demo.bean.Authority;
import com.niit.demo.dao.IAuthorityDao;
import com.niit.demo.dao.impl.AuthorityDaoImpl;
import com.niit.demo.service.IAuthorityService;
import com.sun.org.apache.bcel.internal.generic.NEW;

/**
* ClassName:AuthorityServiceImpl <br/>
* Function: TODO ADD FUNCTION. <br/>
* Reason: TODO ADD REASON. <br/>
* Date: 2017年3月1日 下午2:19:51 <br/>
* @author Tony
* @version
* @see
*/
public class AuthorityServiceImpl implements IAuthorityService {

	IAuthorityDao authorityDao = new AuthorityDaoImpl();
	
	@Override
	public List<Authority> getAuthorityList(Account account) throws Exception {

		return authorityDao.getAuthorityList(account);

	}

}

