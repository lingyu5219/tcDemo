package com.niit.demo.servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.niit.demo.bean.Account;
import com.niit.demo.bean.Video;
import com.niit.demo.service.IVideoService;
import com.niit.demo.service.impl.VideoServiceImpl;
import com.sun.org.apache.bcel.internal.generic.NEW;

/**
 * Servlet implementation class UserCenterServlet
 */
@WebServlet("/userCenter")
public class UserCenterServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	private IVideoService videoService = new VideoServiceImpl();
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UserCenterServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession();
		Account account = (Account)session.getAttribute("account");
		if(null != account){
			try {
				List<Video> videoList = videoService.getVideoList(account.getId());
				request.setAttribute("videoList", videoList);
			} catch (Exception e) {
				e.printStackTrace();
				
			}
			request.getRequestDispatcher("/WEB-INF/jsp/userCenter.jsp").forward(request, response);
		} else {
			//request.getRequestDispatcher("/index").forward(request, response);
			response.sendRedirect("index");
		}
	}
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
