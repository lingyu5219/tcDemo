package com.niit.demo.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;


public class DbManager {
//	private static final String url = "jdbc:mysql://10.10.4.125:3306/video?user=stu_test&password=stu_test";
	private static final String dbName = "videowsdemo";
	private static final String userName = "videowsdemo";
	private static final String passwrod = "videowsdemo";
	private static final String url = "jdbc:mysql://localhost:3306/" + dbName;
	/**
	 * 加载驱动
	 */
	static{
		try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}
	
	
	public static Connection getConnection() throws SQLException{
		return  DriverManager.getConnection(url,userName,passwrod);
//		return  DriverManager.getConnection(url);
	}
	
	/**
	 * 
	* executeUpdate:执行对数据库的增删改操作. <br/>
	* TODO(这里描述这个方法适用条件 – 可选).<br/>
	* TODO(这里描述这个方法的执行流程 – 可选).<br/>
	* TODO(这里描述这个方法的使用方法 – 可选).<br/>
	* TODO(这里描述这个方法的注意事项 – 可选).<br/>
	*
	* @author Tony
	* @param sql
	* @return
	 */
	public static int executeUpdate(String sql){
		Connection conn = null;
		int result = 0;
		try {
			conn = DbManager.getConnection();
			Statement stmt = conn.createStatement();
			result = stmt.executeUpdate(sql);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally{
			try {
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return result;
	}
	
	public static ResultSet executeQuery(Connection conn, String sql) throws Exception{
		ResultSet rs = null;
		try {
			Statement stmt = conn.createStatement();
			rs = stmt.executeQuery(sql);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return rs;
	}
	
	
	public static void main(String args[]) throws Exception{
		int rs = DbManager.executeUpdate("insert into account(username,password) values('bbb','bbb')");
		System.out.println(rs);
	}
}
