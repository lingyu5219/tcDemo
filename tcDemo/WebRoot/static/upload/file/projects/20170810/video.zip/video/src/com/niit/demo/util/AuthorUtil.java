
/**
* Project Name:video
* File Name:AuthorUtil.java
* Package Name:com.niit.demo.util
* Date:2017年3月1日下午1:57:29
* Copyright (c) 2017, Tony All Rights Reserved.
*
*/

package com.niit.demo.util;

import java.util.HashMap;
import java.util.List;

import com.niit.demo.bean.Authority;
import com.niit.demo.service.IAuthorityService;
import com.niit.demo.service.impl.AuthorityServiceImpl;

/**
* ClassName:AuthorUtil <br/>
* Function: TODO ADD FUNCTION. <br/>
* Reason: TODO ADD REASON. <br/>
* Date: 2017年3月1日 下午1:57:29 <br/>
* @author Tony
* @version
* @see
*/
public class AuthorUtil {
	private static HashMap<String,Authority> authorMap = new HashMap<String,Authority>();
	
	static{
		IAuthorityService authorityService = new AuthorityServiceImpl();
		try {
			List<Authority> authorityList = authorityService.getAuthorityList(null);
			
			for(Authority authority : authorityList){
				authorMap.put(authority.getFunction(), authority);
			}
			
		} catch (Exception e) {
			e.printStackTrace();
			
		}
	}
	
	public static HashMap<String,Authority> getAuthorityMap() {
		return authorMap;
	}
	
}

