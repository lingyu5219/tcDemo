
/**
* Project Name:video
* File Name:VideoDaoImpl.java
* Package Name:com.niit.demo.dao.impl
* Date:2017年2月23日下午2:26:08
* Copyright (c) 2017, Tony All Rights Reserved.
*
*/

package com.niit.demo.dao.impl;

import java.net.ConnectException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.niit.demo.bean.Video;
import com.niit.demo.dao.IVideoDao;
import com.niit.demo.util.DbManager;

/**
* ClassName:VideoDaoImpl <br/>
* Function: TODO ADD FUNCTION. <br/>
* Reason: TODO ADD REASON. <br/>
* Date: 2017年2月23日 下午2:26:08 <br/>
* @author Tony
* @version
* @see
*/
public class VideoDaoImpl implements IVideoDao {

	@Override
	public List<Video> getVideoList() throws Exception {
		List<Video> videoList = new ArrayList<Video>();
		
		StringBuffer sql = new StringBuffer("select * from video");
		
		Connection conn = DbManager.getConnection();
		//结果集
		ResultSet rs = DbManager.executeQuery(conn, sql.toString());
		
		while(rs.next()){
			Video video = new Video();
			video.setId(rs.getInt("id"));
			video.setTitle(rs.getString("title"));
			video.setDesc(rs.getString("desc"));
			video.setCreatetime(rs.getString("createtime"));
			video.setPicpath(rs.getString("picpath"));
			video.setVideoPath(rs.getString("videopath"));
			
			videoList.add(video);
		}
		
		conn.close();
		
		return videoList;
	}

	
	public static void main(String args[]) throws Exception{
		VideoDaoImpl videoDao = new VideoDaoImpl();
		List<Video> videoList = videoDao.getVideoList();
		System.out.println(videoList.size());
	}


	@Override
	public List<Video> getVideoList(int accountId) throws Exception {
		
		List<Video> videoList = new ArrayList<Video>();
		
		StringBuffer sql = new StringBuffer("select * from video where account_id = ")
				.append(accountId);
		
		Connection conn = DbManager.getConnection();
		//结果集
		ResultSet rs = DbManager.executeQuery(conn, sql.toString());
		
		while(rs.next()){
			Video video = new Video();
			video.setId(rs.getInt("id"));
			video.setTitle(rs.getString("title"));
			video.setDesc(rs.getString("desc"));
			video.setCreatetime(rs.getString("createtime"));
			video.setPicpath(rs.getString("picpath"));
			video.setVideoPath(rs.getString("videopath"));
			
			videoList.add(video);
		}
		
		conn.close();
		
		return videoList;
		
	}


	@Override
	public List<Video> getVideoList(Video video) throws Exception {
		List<Video> videoList = new ArrayList<Video>();
		
		StringBuffer sql = new StringBuffer("select * from video where 1=1");
		
		if(null != video.getTitle() && !"".equals(video.getTitle())){
			sql.append(" and title like '%").append(video.getTitle()).append("%'");
		}
		
		if(video.getAccount_id() != 0){
			sql.append(" and account_id = ").append(video.getAccount_id());
		}
		
		Connection conn = DbManager.getConnection();
		//结果集
		ResultSet rs = DbManager.executeQuery(conn, sql.toString());
		
		while(rs.next()){
			Video vd = new Video();
			vd.setId(rs.getInt("id"));
			vd.setTitle(rs.getString("title"));
			vd.setDesc(rs.getString("desc"));
			vd.setCreatetime(rs.getString("createtime"));
			vd.setPicpath(rs.getString("picpath"));
			vd.setVideoPath(rs.getString("videopath"));
			
			videoList.add(vd);
		}
		
		conn.close();
		
		return videoList;
	}


	@Override
	public int delVideo(int id) throws Exception {
		
		StringBuffer sql = new StringBuffer("delete from video where id = ")
				.append(id);
		
		return DbManager.executeUpdate(sql.toString());
	}


	@Override
	public int addVideo(Video video) throws Exception {
		StringBuffer sql = new StringBuffer("insert into video(title,video.desc,picpath,videopath,account_id) values('")
				.append(video.getTitle()).append("','")
				.append(video.getDesc()).append("','")
				.append(video.getPicpath()).append("','")
				.append(video.getVideoPath()).append("',")
				.append(video.getAccount_id()).append(")");
		
		return DbManager.executeUpdate(sql.toString());
	}


	@Override
	public Video getVideo(int id) throws Exception {
		Video video = null;
		StringBuffer sql = new StringBuffer("select * from video where id = ")
				.append(id);
		
		Connection conn = DbManager.getConnection();
		//结果集
		ResultSet rs = DbManager.executeQuery(conn, sql.toString());
		
		while(rs.next()){
			video = new Video();
			video.setId(rs.getInt("id"));
			video.setTitle(rs.getString("title"));
			video.setDesc(rs.getString("desc"));
			video.setCreatetime(rs.getString("createtime"));
			video.setPicpath(rs.getString("picpath"));
			video.setVideoPath(rs.getString("videopath"));
		}
		
		conn.close();
		
		return video;
	}


	@Override
	public int updateVideo(Video video) throws Exception {
		StringBuffer sql = new StringBuffer("update video set title = '")
				.append(video.getTitle()).append("', video.desc = '")
				.append(video.getDesc()).append("', picpath = '")
				.append(video.getPicpath()).append("', videopath = '")
				.append(video.getVideoPath()).append("', account_id = ")
				.append(video.getAccount_id())
				.append(" where id = ").append(video.getId());
		
		return DbManager.executeUpdate(sql.toString());
	}
}

