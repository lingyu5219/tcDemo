
/**
* Project Name:video
* File Name:AuthorityDaoImpl.java
* Package Name:com.niit.demo.dao.impl
* Date:2017年3月1日下午2:05:40
* Copyright (c) 2017, Tony All Rights Reserved.
*
*/

package com.niit.demo.dao.impl;

import java.sql.Connection;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.niit.demo.bean.Account;
import com.niit.demo.bean.Authority;
import com.niit.demo.bean.Video;
import com.niit.demo.dao.IAuthorityDao;
import com.niit.demo.util.DbManager;

/**
* ClassName:AuthorityDaoImpl <br/>
* Function: TODO ADD FUNCTION. <br/>
* Reason: TODO ADD REASON. <br/>
* Date: 2017年3月1日 下午2:05:40 <br/>
* @author Tony
* @version
* @see
*/
public class AuthorityDaoImpl implements IAuthorityDao {

	@Override
	public List<Authority> getAuthorityList(Account account) throws Exception {

		StringBuffer sql = new StringBuffer("SELECT * FROM authority where 1=1 ");
		
		if(null != account && null != account.getRole() && !"".equals(account.getRole())) {
			sql.append("and locate('").append(account.getRole()).append("',roles) > 0");
		}

		List<Authority> authorList = new ArrayList<Authority>();
		
		Connection conn = DbManager.getConnection();
		//结果集
		ResultSet rs = DbManager.executeQuery(conn, sql.toString());
		
		while(rs.next()){
			Authority author = new Authority();
			author.setId(rs.getInt("id"));
			author.setDescription(rs.getString("description"));
			author.setFunction(rs.getString("function"));
			author.setRoles(rs.getString("roles"));
			
			authorList.add(author);
		}
		
		conn.close();
		
		return authorList;
	}

}

