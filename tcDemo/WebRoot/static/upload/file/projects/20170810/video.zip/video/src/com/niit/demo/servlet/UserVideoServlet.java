package com.niit.demo.servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.niit.demo.bean.Account;
import com.niit.demo.bean.Video;
import com.niit.demo.service.IVideoService;
import com.niit.demo.service.impl.VideoServiceImpl;

/**
 * Servlet implementation class UserVideoServlet
 */
@WebServlet("/userVideo")
public class UserVideoServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	private IVideoService videoService = new VideoServiceImpl();
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UserVideoServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String title = request.getParameter("title");
		HttpSession session = request.getSession();
		Account account = (Account)session.getAttribute("account");
		
		if(null != account){
			Video video = new Video();
			video.setTitle(title);
			video.setAccount_id(account.getId());
			try {
				List<Video> videoList = videoService.getVideoList(video);
				request.setAttribute("videoList", videoList);
			} catch (Exception e) {
				e.printStackTrace();
				
			}
			request.getRequestDispatcher("/WEB-INF/jsp/userVideo.jsp").forward(request, response);
		} else {
			//request.getRequestDispatcher("/index").forward(request, response);
			response.sendRedirect("index");
		}
	
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
