
/**
* Project Name:video
* File Name:IVideoDao.java
* Package Name:com.niit.demo.dao
* Date:2017年2月23日下午2:06:35
* Copyright (c) 2017, Tony All Rights Reserved.
*
*/

package com.niit.demo.dao;

import java.util.List;

import com.niit.demo.bean.Account;
import com.niit.demo.bean.Video;

/**
* ClassName:IVideoDao <br/>
* Function: TODO ADD FUNCTION. <br/>
* Reason: TODO ADD REASON. <br/>
* Date: 2017年2月23日 下午2:06:35 <br/>
* @author Tony
* @version
* @see
*/
public interface IVideoDao {
	public List<Video> getVideoList() throws Exception;
	
	public List<Video> getVideoList(int accountId) throws Exception;
	
	public List<Video> getVideoList(Video video) throws Exception;
	
	public int delVideo(int id) throws Exception;
	
	public int addVideo(Video video) throws Exception;
	
	public int updateVideo(Video video) throws Exception;
	
	public Video getVideo(int id) throws Exception;
}

