package com.niit.demo.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.niit.demo.service.IVideoService;
import com.niit.demo.service.impl.VideoServiceImpl;

import sun.net.NetworkServer;

/**
 * Servlet implementation class DelVideoServlet
 */
@WebServlet("/delVideo")
public class DelVideoServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	private IVideoService videoService = new VideoServiceImpl();
	
    /**
     * @see HttpServlet#HttpServlet()
     */
    public DelVideoServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String videoId = request.getParameter("id");
		int id = 0;
		if(null != videoId){
			id = Integer.parseInt(videoId);
		}
		
		try {
			videoService.delVideo(id);
		} catch (Exception e) {
			e.printStackTrace();
		}
		request.getRequestDispatcher("/userVideo").forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
