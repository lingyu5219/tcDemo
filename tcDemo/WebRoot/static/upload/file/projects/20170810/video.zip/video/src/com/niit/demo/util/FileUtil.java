
/**
* Project Name:video
* File Name:FileUtil.java
* Package Name:com.niit.demo.util
* Date:2017年2月28日下午2:46:42
* Copyright (c) 2017, Tony All Rights Reserved.
*
*/

package com.niit.demo.util;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

/**
* ClassName:FileUtil <br/>
* Function: TODO ADD FUNCTION. <br/>
* Reason: TODO ADD REASON. <br/>
* Date: 2017年2月28日 下午2:46:42 <br/>
* @author Tony
* @version
* @see
*/
public class FileUtil {
	public static void readAndWrite(InputStream in, String filePath){
		//获取上传内容
		OutputStream out = null;
		
		//封面图片
		try{
			out = new FileOutputStream(new File(filePath));
			
			int read = 0;
			final byte[] bytes = new byte[1024];
			
			while((read=in.read(bytes)) != -1){
				out.write(bytes, 0 , read);
			}
			
		}catch(Exception e) {
			e.printStackTrace();
		}finally{
			if(out != null){
				try {
					out.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
			if(in != null){
				try {
					in.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
	}
}

