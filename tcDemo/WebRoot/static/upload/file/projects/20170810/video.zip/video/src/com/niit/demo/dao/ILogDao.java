
/**
* Project Name:video
* File Name:ILogDao.java
* Package Name:com.niit.demo.dao
* Date:2017年2月23日上午9:37:32
* Copyright (c) 2017, Tony All Rights Reserved.
*
*/

package com.niit.demo.dao;

import java.sql.SQLException;
import java.util.List;


/**
* ClassName:ILogDao <br/>
* Function: TODO ADD FUNCTION. <br/>
* Reason: TODO ADD REASON. <br/>
* Date: 2017年2月23日 上午9:37:32 <br/>
* @author Tony
* @version
* @see
*/
public interface ILogDao {
	
	public int addLog(int account_id,String log_desc) throws Exception;
	
	//public List<Log> getLogs(String account_name) throws SQLException;
}

