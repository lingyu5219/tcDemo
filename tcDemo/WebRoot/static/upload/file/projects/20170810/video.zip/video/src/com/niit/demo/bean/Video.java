
/**
* Project Name:video
* File Name:Video.java
* Package Name:com.niit.demo.bean
* Date:2017年2月23日下午2:10:00
* Copyright (c) 2017, Tony All Rights Reserved.
*
*/

package com.niit.demo.bean;
/**
* ClassName:Video <br/>
* Function: TODO ADD FUNCTION. <br/>
* Reason: TODO ADD REASON. <br/>
* Date: 2017年2月23日 下午2:10:00 <br/>
* @author Tony
* @version
* @see
*/
public class Video {
	private int id;
	private String title;
	private String desc;
	private String createtime;
	private String picpath;
	private String videoPath;
	private int account_id;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
	
		this.id = id;
	}
	public String getTitle() {
	
		return title;
	}
	public void setTitle(String title) {
	
		this.title = title;
	}
	public String getDesc() {
	
		return desc;
	}
	public void setDesc(String desc) {
	
		this.desc = desc;
	}
	public String getCreatetime() {
	
		return createtime;
	}
	public void setCreatetime(String createtime) {
	
		this.createtime = createtime;
	}
	public String getPicpath() {
	
		return picpath;
	}
	public void setPicpath(String picpath) {
	
		this.picpath = picpath;
	}
	public String getVideoPath() {
	
		return videoPath;
	}
	public void setVideoPath(String videoPath) {
	
		this.videoPath = videoPath;
	}
	public int getAccount_id() {
	
		return account_id;
	}
	public void setAccount_id(int account_id) {
	
		this.account_id = account_id;
	}
	
}

