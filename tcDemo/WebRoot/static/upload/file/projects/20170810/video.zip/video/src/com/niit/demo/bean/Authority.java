
/**
* Project Name:video
* File Name:Authority.java
* Package Name:com.niit.demo.bean
* Date:2017年3月1日下午2:00:11
* Copyright (c) 2017, Tony All Rights Reserved.
*
*/

package com.niit.demo.bean;
/**
* ClassName:Authority <br/>
* Function: TODO ADD FUNCTION. <br/>
* Reason: TODO ADD REASON. <br/>
* Date: 2017年3月1日 下午2:00:11 <br/>
* @author Tony
* @version
* @see
*/
public class Authority {
	private int id;
	private String description;
	private String function;
	private String roles;
	public int getId() {
	
		return id;
	}
	public void setId(int id) {
	
		this.id = id;
	}
	public String getDescription() {
	
		return description;
	}
	public void setDescription(String description) {
	
		this.description = description;
	}
	public String getFunction() {
	
		return function;
	}
	public void setFunction(String function) {
	
		this.function = function;
	}
	public String getRoles() {
	
		return roles;
	}
	public void setRoles(String roles) {
	
		this.roles = roles;
	}
	
}

