
/**
* Project Name:video
* File Name:LogDaoImpl.java
* Package Name:com.niit.demo.dao.impl
* Date:2017年2月23日上午9:41:22
* Copyright (c) 2017, Tony All Rights Reserved.
*
*/

package com.niit.demo.dao.impl;

import java.sql.SQLException;

import com.niit.demo.dao.ILogDao;
import com.niit.demo.util.DbManager;

/**
* ClassName:LogDaoImpl <br/>
* Function: TODO ADD FUNCTION. <br/>
* Reason: TODO ADD REASON. <br/>
* Date: 2017年2月23日 上午9:41:22 <br/>
* @author Tony
* @version
* @see
*/
public class LogDaoImpl implements ILogDao {

	@Override
	public int addLog(int account_id, String log_desc) throws Exception {
		
		StringBuffer sb = new StringBuffer("insert into user_log (account_id,description) values (")
				.append(account_id)
				.append(",'")
				.append(log_desc)
				.append("')");
		return DbManager.executeUpdate(sb.toString());

	}

}

