package com.niit.demo.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.eclipse.jdt.internal.compiler.ast.ThrowStatement;

import com.niit.demo.bean.Video;
import com.niit.demo.service.IVideoService;
import com.niit.demo.service.impl.VideoServiceImpl;
import com.sun.org.apache.bcel.internal.generic.NEW;

/**
 * Servlet implementation class PlayVideoServlet
 */
@WebServlet("/playVideo")
public class PlayVideoServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	private IVideoService videoService = new VideoServiceImpl();
    /**
     * @see HttpServlet#HttpServlet()
     */
    public PlayVideoServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String id = request.getParameter("id");
		int videoId = 0;
		if (null != id && !"".equals(id)) {
			videoId = Integer.parseInt(id);
			try {
				Video video = videoService.getVideo(videoId);
				request.setAttribute("video", video);
				request.getRequestDispatcher("/WEB-INF/jsp/playVideo.jsp").forward(request, response);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
