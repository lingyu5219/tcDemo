
/**
* Project Name:video
* File Name:VideoServiceImpl.java
* Package Name:com.niit.demo.service.impl
* Date:2017年2月23日下午2:53:51
* Copyright (c) 2017, Tony All Rights Reserved.
*
*/

package com.niit.demo.service.impl;

import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.servlet.http.Part;

import com.niit.demo.bean.Account;
import com.niit.demo.bean.Video;
import com.niit.demo.dao.IVideoDao;
import com.niit.demo.dao.impl.VideoDaoImpl;
import com.niit.demo.service.IVideoService;
import com.niit.demo.util.FileUtil;

/**
* ClassName:VideoServiceImpl <br/>
* Function: TODO ADD FUNCTION. <br/>
* Reason: TODO ADD REASON. <br/>
* Date: 2017年2月23日 下午2:53:51 <br/>
* @author Tony
* @version
* @see
*/
public class VideoServiceImpl implements IVideoService {

	IVideoDao videoDao = new VideoDaoImpl();
	
	@Override
	public List<Video> getVideoList() throws Exception {
		
		return videoDao.getVideoList();
		
	}

	@Override
	public List<Video> getVideoList(int accountId) throws Exception {
		
		return videoDao.getVideoList(accountId);
		
	}

	@Override
	public List<Video> getVideoList(Video video) throws Exception {
		
		return videoDao.getVideoList(video);
		
	}

	@Override
	public boolean delVideo(int id) throws Exception {
		
		if (videoDao.delVideo(id) > 0){
			return true;
		} else {
			return false;
		}
	}

	@Override
	public boolean addVideo(HttpServletRequest request) throws Exception {
		HttpSession session = request.getSession();
		Account account = (Account)session.getAttribute("account");
		
		String title = request.getParameter("title");
		String desc = request.getParameter("desc");
		Date now = new Date();
		String picPath = "upload/pic/"+account.getId()+"_"+now.getTime();
		String videoPath = "upload/video/"+account.getId()+"_"+now.getTime();
		
		//域
		Part picPart = request.getPart("pic");
		Part videoPart = request.getPart("video");
		
		
		String realPicPath = request.getServletContext().getRealPath("/").replace("\\","/") + picPath;
		String realVideoPath = request.getServletContext().getRealPath("/").replace("\\","/") + videoPath;
		
		//视频封面图片上传
		FileUtil.readAndWrite(picPart.getInputStream(), realPicPath);
		//视频上传
		FileUtil.readAndWrite(videoPart.getInputStream(), realVideoPath);
		
		//上传之后，我们要将数据保存到数据库中，先将数据封装到一个Video对象中
		Video video = new Video();
		video.setTitle(title);
		video.setDesc(desc);
		video.setPicpath(picPath);
		video.setVideoPath(videoPath);
		video.setAccount_id(account.getId());
		
		int rs = videoDao.addVideo(video);
		if(rs > 0) {
			return true;
		} else {
			return false;
		}
		
	}

	@Override
	public Video getVideo(int id) throws Exception {
		return videoDao.getVideo(id);
	}

	@Override
	public boolean updateVideo(HttpServletRequest request) throws Exception {
		//获取ID值，如果id值是一个整数，说明数据合法，才会执行后续的文件上传以及数据更新操作
		String id = request.getParameter("id");
		int rs = 0;
		if(null != id && !"".equals(id)){
			HttpSession session = request.getSession();
			Account account = (Account)session.getAttribute("account");
			String title = request.getParameter("title");
			String desc = request.getParameter("desc");
			Date now = new Date();
			String picPath = "upload/pic/"+account.getId()+"_"+now.getTime();
			String videoPath = "upload/video/"+account.getId()+"_"+now.getTime();
			
			//域
			Part picPart = request.getPart("pic");
			Part videoPart = request.getPart("video");
			
			
			String realPicPath = request.getServletContext().getRealPath("/").replace("\\","/") + picPath;
			String realVideoPath = request.getServletContext().getRealPath("/").replace("\\","/") + videoPath;
			
			//视频封面图片上传
			FileUtil.readAndWrite(picPart.getInputStream(), realPicPath);
			//视频上传
			FileUtil.readAndWrite(videoPart.getInputStream(), realVideoPath);
			
			//上传之后，我们要将数据保存到数据库中，先将数据封装到一个Video对象中
			Video video = new Video();
			
		
			video.setId(Integer.parseInt(id));
			video.setTitle(title);
			video.setDesc(desc);
			video.setPicpath(picPath);
			video.setVideoPath(videoPath);
			video.setAccount_id(account.getId());
			
			rs = videoDao.updateVideo(video);
			
		}
		if(rs > 0) {
			return true;
		} else {
			return false;
		}
	}
	
}

