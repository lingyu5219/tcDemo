
/**
* Project Name:video
* File Name:IAccountService.java
* Package Name:com.niit.demo.service
* Date:2017年2月27日下午1:30:08
* Copyright (c) 2017, Tony All Rights Reserved.
*
*/

package com.niit.demo.service;

import javax.servlet.http.HttpSession;

import com.niit.demo.bean.Account;

/**
* ClassName:IAccountService <br/>
* Function: TODO ADD FUNCTION. <br/>
* Reason: TODO ADD REASON. <br/>
* Date: 2017年2月27日 下午1:30:08 <br/>
* @author Tony
* @version
* @see
*/
public interface IAccountService {
	public boolean addAccount(Account account) throws Exception;
	
	public boolean checkAccount(HttpSession session, String username, String password) throws Exception;
}

