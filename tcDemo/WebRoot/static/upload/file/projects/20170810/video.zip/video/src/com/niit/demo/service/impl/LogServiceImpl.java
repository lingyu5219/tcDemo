
/**
* Project Name:video
* File Name:LogServiceImpl.java
* Package Name:com.niit.demo.service.impl
* Date:2017年2月23日上午10:02:08
* Copyright (c) 2017, Tony All Rights Reserved.
*
*/

package com.niit.demo.service.impl;

import java.sql.SQLException;

import com.niit.demo.dao.ILogDao;
import com.niit.demo.dao.impl.LogDaoImpl;
import com.niit.demo.service.ILogService;
import com.sun.org.apache.bcel.internal.generic.NEW;

/**
* ClassName:LogServiceImpl <br/>
* Function: TODO ADD FUNCTION. <br/>
* Reason: TODO ADD REASON. <br/>
* Date: 2017年2月23日 上午10:02:08 <br/>
* @author Tony
* @version
* @see
*/
public class LogServiceImpl implements ILogService {
	ILogDao LogDao = new LogDaoImpl();
	
	@Override
	public int addLog(int account_id, String log_desc) throws Exception {

		return LogDao.addLog(account_id, log_desc);

	}

}

