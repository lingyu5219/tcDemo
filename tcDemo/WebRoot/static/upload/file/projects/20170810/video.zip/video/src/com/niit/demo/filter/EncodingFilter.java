
/**
* Project Name:video
* File Name:LogFilter.java
* Package Name:com.niit.demo.filter
* Date:2017年2月23日上午10:08:15
* Copyright (c) 2017, Tony All Rights Reserved.
*
*/

package com.niit.demo.filter;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.niit.demo.bean.Account;
import com.niit.demo.service.ILogService;
import com.sun.net.httpserver.HttpServer;
import com.sun.org.apache.bcel.internal.generic.NEW;
import com.niit.demo.service.impl.LogServiceImpl;

/**
* ClassName:LogFilter <br/>
* Function: TODO ADD FUNCTION. <br/>
* Reason: TODO ADD REASON. <br/>
* Date: 2017年2月23日 上午10:08:15 <br/>
* @author Tony
* @version
* @see
*/
@WebFilter(filterName="F1_encodingFilter",urlPatterns="/*")
public class EncodingFilter implements Filter {

	@Override
	public void destroy() {

		// TODO Auto-generated method stub

	}

	@Override
	public void doFilter(ServletRequest req, ServletResponse res, FilterChain chain)
			throws IOException, ServletException{
		HttpServletRequest request = (HttpServletRequest)req;
		HttpServletResponse response = (HttpServletResponse)res;
		
		request.setCharacterEncoding("UTF-8");  
		response.setContentType("text/html;charset=UTF-8");
        response.setCharacterEncoding("UTF-8");  
		chain.doFilter(req, res);

	}

	@Override
	public void init(FilterConfig arg0) throws ServletException {

		// TODO Auto-generated method stub

	}

}

