
/**
* Project Name:video
* File Name:IAccountDao.java
* Package Name:com.niit.demo.dao
* Date:2017年2月27日下午1:42:28
* Copyright (c) 2017, Tony All Rights Reserved.
*
*/

package com.niit.demo.dao;

import com.niit.demo.bean.Account;

/**
* ClassName:IAccountDao <br/>
* Function: TODO ADD FUNCTION. <br/>
* Reason: TODO ADD REASON. <br/>
* Date: 2017年2月27日 下午1:42:28 <br/>
* @author Tony
* @version
* @see
*/
public interface IAccountDao {
	public int addAccount(Account account) throws Exception;
	
	public Account getAccount(String username) throws Exception;
	
}

