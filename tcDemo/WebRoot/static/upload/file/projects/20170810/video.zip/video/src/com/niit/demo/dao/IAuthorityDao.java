
/**
* Project Name:video
* File Name:IAuthorityDao.java
* Package Name:com.niit.demo.dao
* Date:2017年3月1日下午2:04:05
* Copyright (c) 2017, Tony All Rights Reserved.
*
*/

package com.niit.demo.dao;

import java.util.List;

import com.niit.demo.bean.Account;
import com.niit.demo.bean.Authority;

/**
* ClassName:IAuthorityDao <br/>
* Function: TODO ADD FUNCTION. <br/>
* Reason: TODO ADD REASON. <br/>
* Date: 2017年3月1日 下午2:04:05 <br/>
* @author Tony
* @version
* @see
*/
public interface IAuthorityDao {
	public List<Authority> getAuthorityList(Account account) throws Exception;
}

